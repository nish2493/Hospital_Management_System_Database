package one;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.*;
import java.io.*;

public class Connect {
	
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	
	public Connection con;
	
	void Connecting()

	{
		System.out.println("------PostgreSQL"+"JDBC Connection Testing------");
		try
		{
			Class.forName("org.postgresql.Driver");
		}
		catch(ClassNotFoundException e)
		{
			System.out.println("Where is your PostgreSQL JDBC Driver?"+"Include in your library path!");
			e.printStackTrace();
			return;
		}
		System.out.println("PostgreSQL JDBC Driver Registered!");
		try
		{
			con = DriverManager.getConnection("jdbc:postgresql://cop5725-postgresql.cs.fiu.edu:5432/fall16_nmaur009","fall16_nmaur009","5968168");
		}
		catch(SQLException e)
		{
			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return;
		}
		if(con != null)
		{
			System.out.println("You made it, take control of your database now!");
				
		}
		else
		{
			System.out.println("Failed to make connection!");
		}
	}
	
	void Authentication()
	{
		try
		{
		
		System.out.println("Enter Username :: ");
		String Username = br.readLine();
		System.out.println("Enter Password :: ");
		String Password = br.readLine();
		
		CallableStatement stmt= con.prepareCall("{? = call aunthenticate(?,?)}");
		stmt.setString(2, Username);
		stmt.setString(3, Password);
		stmt.registerOutParameter(1, Types.INTEGER);
		stmt.execute();
		int result = stmt.getInt(1);
	if(result == 1)
	{
		System.out.println("Login Successfull! \n----");
		System.out.println("Do you want to change your password ??(Enter y or n)");
		String Answer = br.readLine();
		if(Answer.equals("y"))
		{
			System.out.println("Enter the new Password :: ");
			String Newpassword = br.readLine();
			CallableStatement stmt1 = con.prepareCall("select updatepassword(?,?,?); ");
			stmt1.setString(1,Username);
			stmt1.setString(2,Password);
			stmt1.setString(3,Newpassword);
			stmt1.execute();
			System.out.println("Password changed Successfully to "+Newpassword+"!!!!");
		}
	}
	else
	{
		System.out.println("Login Unsuccessfull!   Enter Correct Username or Password \n---"); 
	}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	void Retrieve()
	{
		try
		{
			System.out.println("Enter the ID of the Patient to retrieve its data :: ");
			Integer PatientID = Integer.parseInt(br.readLine());
				CallableStatement stmt= con.prepareCall("{call rp(?)}");
				stmt.setInt(1, PatientID);
				ResultSet rs = stmt.executeQuery();
				
				while(rs.next())
				{
					System.out.println("Patient ID :: "+rs.getString(1)+"\n"
				+"Patient First Name :: " +rs.getString(2)+"\n"
				+"Patient Middle Name :: " +rs.getString(3)+"\n"
				+"Patient Last Name :: " +rs.getString(4)+"\n"
				+"Patient Gender :: " +rs.getString(5)+"\n"
				+"Patient Date Of Birth :: " +rs.getString(6));
				}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	void PrefferedCCard()
	{
		try
		{
			System.out.println("Enter the ID of the Patient to set preferred credit card :: ");
			Integer PatientID = Integer.parseInt(br.readLine());
			System.out.println("Enter the Credit Card Number to set as Default :: ");
			String CCNumber = br.readLine();
			
				CallableStatement stmt= con.prepareCall("{call cc1(?,?)}");	
				stmt.setInt(1, PatientID);
				stmt.setString(2, CCNumber);
				ResultSet rs = stmt.executeQuery();
				
				while(rs.next())
				{
					System.out.println("Credit Card set as preferred successfully!!!");
					System.out.println("Patient ID :: "+rs.getString(1)+"\n"
				+"Credit Card Number :: " +rs.getString(2)+"\n"
				+"Address :: " +rs.getString(3));
				}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	void Medicine()
	{
		try
		{
			System.out.println("Enter the ID of the Medicine :: ");
			Integer MID = Integer.parseInt(br.readLine());
			System.out.println("Enter the Date :: ");
			String CDate = br.readLine();
			
				CallableStatement stmt= con.prepareCall("{call Medicine(?,?)}");	
				stmt.setInt(1, MID);
				stmt.setString(2, CDate);
				ResultSet rs = stmt.executeQuery();
				
				while(rs.next())
				{
					System.out.println("Medicine Quantity :: "+rs.getString(1));
				}
		}
		catch(Exception e)
		{
			
		}
	}
	
	void Bill()
	{
		try
		{
			System.out.println("Enter the ID of the Patient to retrieve its Bill :: ");
			Integer PID = Integer.parseInt(br.readLine());
			System.out.println("Enter the date :: ");
			String Date = br.readLine();
				CallableStatement stmt= con.prepareCall("{call bill(?,?)}");
				stmt.setInt(1, PID);
				stmt.setString(2, Date);
				ResultSet rs = stmt.executeQuery();
				
				while( rs.next() )
				{
				 Integer d = +rs.getInt(4);
				 Integer e = +rs.getInt(5);
				 Integer f = +rs.getInt(6);
				 Integer g = +rs.getInt(7);
				 Integer h = +rs.getInt(8);
				 Integer i = +rs.getInt(9);
				 Integer t = (d+e+f+g+h+i);
				System.out.println(
				 "Bill ID " +"Billing Date |" +"PatientID |"+ "DoctorCost |" +"NurseCost |" +"RoomCost |" +"LabCost |"+"RadiologyCost |"+"MedicineCost |"+"Total Bill Amount|"+"\n"
				+rs.getInt(1)+"          " +rs.getString(2) +"       "   +rs.getInt(3)+"        "     +rs.getInt(4) +"            "    +rs.getInt(5) +"        "    +rs.getInt(6) +"       "    +rs.getInt(7)  +"         "   +rs.getInt(8)  +"            "   +rs.getInt(9)+ "            "+t);
				}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	void Updatepassword()
	{
		try
		{
			String DBUsername = "";
			String DBPassword = "";
		
		System.out.println("Enter Username :: ");
		String Username = br.readLine();
		System.out.println("Enter Password :: ");
		String Password = br.readLine();
		
		
	Statement stmt = con.createStatement();
	
	String sql = "select P_EmailAddress, P_Password from xyz.Login where P_EmailAddress = '"+Username+"' and  P_Password = '"+Password+"'";
	
	ResultSet rs= stmt.executeQuery(sql);

	while(rs.next())
	{
		DBUsername = rs.getString("P_EmailAddress");
		DBPassword = rs.getString("P_Password");
	}
	if(Username.equals(DBUsername) && Password.equals(DBPassword))
	{
		
	}
	else
	{
		System.out.println("Enter Correct Username or Password \n---");
	}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	public static void main(String[] args) {
	try
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Connect c=new Connect();
		c.Connecting();
		for(int i=0;i!=200;i++)
		{
		System.out.println("\n 1. Login and change Password \n 2. Retrieve Patient \n 3. Set Prefered Credit Card \n 4. Get Medicine Availablility \n 5. Bill \n 6. END");
		Integer a = Integer.parseInt(br.readLine());
		switch(a)
		{
		case 1:
		{
			c.Authentication();
	break;
		}
		case 2:
		{
			c.Retrieve();
	break;
		}
		case 3:
		{
			c.PrefferedCCard();
	break;
		}
		case 4:
		{
			c.Medicine();
	break;
		}
		case 5:
		{
			c.Bill();
	break;
		}
		case 6:
		{
			System.out.println("--------Program Terminated--------");
			System.exit(0);
		}
		default:
		{
			System.out.println("Invalid Selection");
			break;
		}
		}
	//c.Updatepassword();
	}
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	}
}

	

