Project 3 - Part 1
1) Copy the folder project3_part1 into your workspace.
2) Open the java file in src->abc folder using eclipse.
3) Execute the Java file.
4) If a driver exception occurs : 1) There is a jdbc driver available in the "project3_part2->src" folder.
				  2) Right click on "JRE System Library" and select "Build Path-> Configure Build Path.."
				  3) Press "Add JARS..." button present on the right side.
				  4) Select "Project3_part2->src->postgresql-9.3-1103.jdbc3.jar" and cick "OK" button.
				  5) Click on "Apply" button and click "OK" button.
					You have successfully added the required drivers!!
5) You will get 6 Options to select from :
	Option 1) Login using username and password(Authentication takes place using SQL Function). Some Login Credentials :: Username				Password
									       nish2493@rocketmail.com		nish
									       abc@yahoo.com			abc
									       pqr@yahoo.com			pqr
		  Output : It was Show Successfull login, and it will ask you whether you want to change the password and give you two options 'y' and 'n'. Type any 1 and press Enter. If you entered incorrect id and password it will give you an error.
		  If you want to change your password you can by Entering 'y' and then a new password.

	Option 2) Retrieve Patient Information : You can Enter any Patient Id to retrieve its details. Some PIDs are : 1,2,3,4,5
			Output : It will display Users Details

	Option 3) Set Prefered Credit Card : Enter the Id of the Patient and hit Enter, then enter the Credit card number you want to set as a default credit card
					     Some Pids and Credit Card Details that you can Enter : PIDs	Credit Card Number
												     1		12345678
												     2		23456789
			Output : It will show The Users ID, Credit Card Number and successfully changed message.
												     
	Option 4) Get Medicine Availability: Enter the ID of the Medicine and the Date of which you want the availability for that medicine
					     Some Inputs are : Medicine ID	Date 
								1		8/10/2016	
								2		6/3/2016
								3		9/14/2016
								4		8/30/2016
			Output : It will show the Current Quantity of Medicine available.

	Option 5) Get the Bill For the Patient on a particular date.
		  Some Inputs are : Patient ID		Date
					1		2016-2-7
					2		2016-3-8
					3		2016-7-22
					4		2016-7-21
			Output : It will display all the Costs that are associated with the patient with that ID.

	Option 6) Selecting this Option will take you out of the Program by Terminating JVM.