package abc;

import java.io.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.sql.*;

public class Part2 {
public static void main (String[] args)
{int z=0;
	try
	{
		Connection con = DriverManager.getConnection("jdbc:postgresql://cop5725-postgresql.cs.fiu.edu:5432/fall16_nmaur009","fall16_nmaur009","5968168");
		File inputFile = new File("InputXML.txt");
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(inputFile);
		doc.getDocumentElement().normalize();
		
		NodeList nList = doc.getElementsByTagName("patient");
		for(int temp = 0; temp < nList.getLength(); temp++)
		{
			Node nNode = nList.item(temp);
		if(nNode.getNodeType() == Node.ELEMENT_NODE)
		{
			Element eElement = (Element) nNode;
			System.out.println("SSN :" +eElement.getElementsByTagName("SSN").item(0).getTextContent());
			System.out.println("First Name :" +eElement.getElementsByTagName("FIRSTNAME").item(0).getTextContent());
			System.out.println("Middle Name :" +eElement.getElementsByTagName("MIDDLENAME").item(0).getTextContent());
			System.out.println("Last Name :" +eElement.getElementsByTagName("LASTNAME").item(0).getTextContent());
			System.out.println("Email ID :" +eElement.getElementsByTagName("EMAIL").item(0).getTextContent());
			System.out.println("Phone Number :" +eElement.getElementsByTagName("PHONENUMBER").item(0).getTextContent());
			System.out.println("Password :" +eElement.getElementsByTagName("PASSWORD").item(0).getTextContent());
			System.out.println("Balance Amount :" +eElement.getElementsByTagName("BALANCEAMOUNT").item(0).getTextContent());
			System.out.println("Insurance Policy Number :" +eElement.getElementsByTagName("INSURANCEPOLICYNO").item(0).getTextContent());
			System.out.println("Gender :" +eElement.getElementsByTagName("GENDER").item(0).getTextContent());
			System.out.println("Date of Birth :" +eElement.getElementsByTagName("DATEOFBIRTH").item(0).getTextContent());
			
			String ssn = eElement.getElementsByTagName("SSN").item(0).getTextContent();
			String firstname = eElement.getElementsByTagName("FIRSTNAME").item(0).getTextContent();
			String middlename = eElement.getElementsByTagName("MIDDLENAME").item(0).getTextContent();
			String lastname = eElement.getElementsByTagName("LASTNAME").item(0).getTextContent();
			String emailid = eElement.getElementsByTagName("EMAIL").item(0).getTextContent();
			String phoneno = eElement.getElementsByTagName("PHONENUMBER").item(0).getTextContent();
			String password = eElement.getElementsByTagName("PASSWORD").item(0).getTextContent();
			String balanceamount = eElement.getElementsByTagName("BALANCEAMOUNT").item(0).getTextContent();
			String insurance = eElement.getElementsByTagName("INSURANCEPOLICYNO").item(0).getTextContent();
			String gender = eElement.getElementsByTagName("GENDER").item(0).getTextContent();
			String dob = eElement.getElementsByTagName("DATEOFBIRTH").item(0).getTextContent();
			CallableStatement stmt= con.prepareCall("{call p(?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.setString(1,ssn);
			stmt.setString(2,firstname);
			stmt.setString(3,middlename);
			stmt.setString(4,lastname);
			stmt.setString(5,emailid);
			stmt.setString(6,phoneno);
			stmt.setString(7,password);
			stmt.setString(8,balanceamount);
			stmt.setString(9,insurance);
			stmt.setString(10,gender);
			stmt.setString(11,dob);
			stmt.executeQuery();
			PreparedStatement p = con.prepareStatement("select P_ID from pqr.Patient where SSN = ?");
			p.setString(1, ssn);
			ResultSet rs = p.executeQuery();
			while (rs.next())
			{
			z = rs.getInt(1);
			}
		}
	}
		NodeList n1List = doc.getElementsByTagName("creditcard");
		for(int temp = 0; temp < n1List.getLength(); temp++)
		{
			Node n1Node = n1List.item(temp);
		
		if(n1Node.getNodeType() == Node.ELEMENT_NODE)
		{
			Element eElement = (Element) n1Node;
			System.out.println("Credit Card Number :" +eElement.getElementsByTagName("CREDITCARDNUMBER").item(0).getTextContent());
			System.out.println("Billing Address :" +eElement.getElementsByTagName("BILLADDRESS").item(0).getTextContent());
			System.out.println("Prefered to use ?? :" +eElement.getElementsByTagName("IFPREFEREDTOUSE").item(0).getTextContent());
			System.out.println("Prefered billing address :" +eElement.getElementsByTagName("IFMAILPAPERBILL").item(0).getTextContent());
			
			String creditcardnumber = eElement.getElementsByTagName("CREDITCARDNUMBER").item(0).getTextContent();
			String billaddress = eElement.getElementsByTagName("BILLADDRESS").item(0).getTextContent();
			String prefered = eElement.getElementsByTagName("IFPREFEREDTOUSE").item(0).getTextContent();
			String bill = eElement.getElementsByTagName("IFMAILPAPERBILL").item(0).getTextContent();
			CallableStatement stmt= con.prepareCall("{call cc(?,?,?,?)}");
			stmt.setString(1, creditcardnumber);
			stmt.setString(2, billaddress);
			stmt.setString(3, prefered);
			stmt.setString(4, bill);
			stmt.executeQuery();
			PreparedStatement p1 = con.prepareStatement("update pqr.Credit_Cards set P_ID = ? where CreditCardNumber = ?");
			p1.setInt(1,z);
			p1.setString(2, creditcardnumber);
			p1.execute();
		}
		}
		
		NodeList n2List = doc.getElementsByTagName("checkinrecord");
		for(int temp = 0; temp < n2List.getLength(); temp++)
		{
			Node n2Node = n2List.item(temp);
	
		if(n2Node.getNodeType() == Node.ELEMENT_NODE)
		{
			Element eElement = (Element) n2Node;
			System.out.println("Nurse ID :" +eElement.getElementsByTagName("nurseid").item(0).getTextContent());
			System.out.println("Height :" +eElement.getElementsByTagName("HEIGHT").item(0).getTextContent());
			System.out.println("Weight :" +eElement.getElementsByTagName("WEIGHT").item(0).getTextContent());
			System.out.println("BloodPressure :" +eElement.getElementsByTagName("BLOODPRESSURE").item(0).getTextContent());
			System.out.println("BodyTemprature :" +eElement.getElementsByTagName("BODYTEMPERATURE").item(0).getTextContent());
			System.out.println("Checkin Time :" +eElement.getElementsByTagName("CHECKINTIME").item(0).getTextContent());
			
			String nid = eElement.getElementsByTagName("nurseid").item(0).getTextContent();
			String height = eElement.getElementsByTagName("HEIGHT").item(0).getTextContent();
			String weight = eElement.getElementsByTagName("WEIGHT").item(0).getTextContent();
			String bp = eElement.getElementsByTagName("BLOODPRESSURE").item(0).getTextContent();
			String bt = eElement.getElementsByTagName("BODYTEMPERATURE").item(0).getTextContent();
			String ct = eElement.getElementsByTagName("CHECKINTIME").item(0).getTextContent();
			CallableStatement stmt= con.prepareCall("{call c(?,?,?,?,?,?)}");
			stmt.setString(1, nid);
			stmt.setString(2, height);
			stmt.setString(3, weight);
			stmt.setString(4, bp);
			stmt.setString(5, bt);
			stmt.setString(6, ct);
			stmt.executeQuery();
		}
		}
}
	catch(Exception e)
	{
		e.printStackTrace();
	}
}
}
