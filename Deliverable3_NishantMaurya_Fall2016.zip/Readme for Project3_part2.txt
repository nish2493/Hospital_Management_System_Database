Project 3 - Part 2
1) Copy the folder project3_part2 into your workspace.
2) Open the java file in src->abc folder using eclipse.
3) Execute the Java file.
4) If a driver exception occurs : 1) There is a jdbc driver available in the "project3_part2->src" folder.
				  2) Right click on "JRE System Library" and select "Build Path-> Configure Build Path.."
				  3) Press "Add JARS..." button present on the right side.
				  4) Select "Project3_part2->src->postgresql-9.3-1103.jdbc3.jar" and cick "OK" button.
				  5) Click on "Apply" button and click "OK" button.
					You have successfully added the required drivers!!
5) The data will get inserted into the database tables and will give you the required output on the console.

6) If you want to add your own Input Xml file : 1) Replace the Line 14 in the Code i.e : File inputFile = new File("InputXML.txt");
						   Replace it with the code : File inputFile = new File("Your File Name");
						   It is necessary that you copy your own new input xml file in the Project3_part2 folder.