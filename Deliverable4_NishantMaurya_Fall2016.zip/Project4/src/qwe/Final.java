package qwe;

import java.io.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.sql.*;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.*;
import javax.swing.*;
import java.text.*;


public class Final {
	public static void main(String args[])
	{
		int z = 0;			// P_ID
		int q = 0;			// B_ID
		int c = 0;			//
		int x = 0;			//	
		int v = 0;			//
		int k = 0;			//	
		int j = 0;			//
		String qw = null;	//ccnumber
		String wq = null;	//billing address
		int dc = 0;			//doctor cost
		int ld = 0;			//lab cost
		int rd = 0;			//radiology cost
		int md = 0;			//Medicine ID
		int nc = 0;			//Nurse Cost
		long qq = 0;		//Number of days room is occupied
		int dr = 0; 		//Room Cost
		int mcost = 0;		//Medicine total cost
		String pp = null;	//Insurance Policy Status
		int cp1 = 0;		//Coverage Percentage
		int ii = 0;			//Inquiry ID
		int ri = 0; 		//Reminder ID
		String rrr = null;	//Billing Reminder Record
		int ca = 0;			//Current Medicine Amount
		int tt = 0;			//Threshold for medicine
		String rrrr=null;	//Restore Reminder
		
		try
		{
			Connection con = DriverManager.getConnection("jdbc:postgresql://cop5725-postgresql.cs.fiu.edu:5432/fall16_nmaur009","fall16_nmaur009","5968168");
			File inputFile = new File("InputXml.txt");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			
			NodeList nList = doc.getElementsByTagName("Patient");
			for(int temp = 0; temp < nList.getLength(); temp++)
			{
				Node nNode = nList.item(temp);
			if(nNode.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) nNode;
				/*System.out.println("SSN : " +eElement.getElementsByTagName("SSN").item(0).getTextContent());
				System.out.println("First Name : " +eElement.getElementsByTagName("FIRSTNAME").item(0).getTextContent());
				System.out.println("Middle Name : " +eElement.getElementsByTagName("MIDDLENAME").item(0).getTextContent());
				System.out.println("Last Name : " +eElement.getElementsByTagName("LASTNAME").item(0).getTextContent());
				System.out.println("Email ID : " +eElement.getElementsByTagName("EMAIL").item(0).getTextContent());
				System.out.println("Phone Number : " +eElement.getElementsByTagName("PHONENUMBER").item(0).getTextContent());
				System.out.println("Password : " +eElement.getElementsByTagName("PASSWORD").item(0).getTextContent());
				System.out.println("Balance Amount : " +eElement.getElementsByTagName("BALANCEAMOUNT").item(0).getTextContent());
				System.out.println("Insurance Policy Number : " +eElement.getElementsByTagName("INSURANCEPOLICYNO").item(0).getTextContent());
				System.out.println("Gender : " +eElement.getElementsByTagName("GENDER").item(0).getTextContent());
				System.out.println("Date of Birth : " +eElement.getElementsByTagName("DATEOFBIRTH").item(0).getTextContent());*/
				
				Integer social = Integer.parseInt(eElement.getElementsByTagName("SSN").item(0).getTextContent());
				String firstname = eElement.getElementsByTagName("FIRSTNAME").item(0).getTextContent();
				String middlename = eElement.getElementsByTagName("MIDDLENAME").item(0).getTextContent();
				String lastname = eElement.getElementsByTagName("LASTNAME").item(0).getTextContent();
				String emailid = eElement.getElementsByTagName("EMAIL").item(0).getTextContent();
				String phoneno = eElement.getElementsByTagName("PHONENUMBER").item(0).getTextContent();
				String password = eElement.getElementsByTagName("PASSWORD").item(0).getTextContent();
				Integer balanceamount = Integer.parseInt(eElement.getElementsByTagName("BALANCEAMOUNT").item(0).getTextContent());
				String insurance = eElement.getElementsByTagName("INSURANCEPOLICYNO").item(0).getTextContent();
				String gender = eElement.getElementsByTagName("GENDER").item(0).getTextContent();
				String dob = eElement.getElementsByTagName("DATEOFBIRTH").item(0).getTextContent();
				CallableStatement stmt= con.prepareCall("{call qwe.patients(?,?,?,?,?,?,?,?,?,?,?)}");
				stmt.setInt(1,social);
				stmt.setString(2,firstname);
				stmt.setString(3,middlename);
				stmt.setString(4,lastname);
				stmt.setString(5,emailid);
				stmt.setString(6,phoneno);
				stmt.setString(7,password);
				stmt.setInt(8,balanceamount);
				stmt.setString(9,insurance);
				stmt.setString(10,gender);
				stmt.setString(11,dob);
				stmt.executeQuery();
				PreparedStatement p = con.prepareStatement("select P_ID from qwe.Patient where SSN = ?");
				p.setInt(1, social);
				ResultSet rs = p.executeQuery();
				while (rs.next())
				{
				z = rs.getInt(1);
				}
			}
		}
			
			NodeList n1List = doc.getElementsByTagName("CREDITCARDS");
			for(int temp = 0; temp < n1List.getLength(); temp++)
			{
				Node n1Node = n1List.item(temp);
			
			if(n1Node.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) n1Node;
				/*System.out.println("Credit Card Number : " +eElement.getElementsByTagName("CREDITCARDNUMBER").item(0).getTextContent());
				System.out.println("Billing Address : " +eElement.getElementsByTagName("BILLADDRESS").item(0).getTextContent());
				System.out.println("Prefered to use ?? : " +eElement.getElementsByTagName("IFPREFEREDTOUSE").item(0).getTextContent());
				System.out.println("Prefered billing address : " +eElement.getElementsByTagName("IFMAILPAPERBILL").item(0).getTextContent());*/
				
				String creditcardnumber = eElement.getElementsByTagName("CREDITCARDNUMBER").item(0).getTextContent();
				String billaddress = eElement.getElementsByTagName("BILLADDRESS").item(0).getTextContent();
				String prefered = eElement.getElementsByTagName("IFPREFEREDTOUSE").item(0).getTextContent();
				String bill = eElement.getElementsByTagName("IFMAILPAPERBILL").item(0).getTextContent();
				CallableStatement stmt= con.prepareCall("{call qwe.cc(?,?,?,?)}");
				stmt.setString(1, creditcardnumber);
				stmt.setString(2, billaddress);
				stmt.setString(3, prefered);
				stmt.setString(4, bill);
				stmt.executeQuery();
				PreparedStatement p1 = con.prepareStatement("update qwe.CCDetails set P_ID = ? where CCNumber = ?");
				p1.setInt(1,z);
				p1.setString(2, creditcardnumber);
				p1.execute();
				PreparedStatement p = con.prepareStatement("select CCNumber from qwe.CCDetails where P_ID = ? and IFPrefToUse = ?");
				p.setInt(1, z);
				p.setString(2, prefered);
				ResultSet rs = p.executeQuery();
				while (rs.next())
				{
				qw = rs.getString(1);
				}
				PreparedStatement p2 = con.prepareStatement("select B_Address from qwe.CCDetails where CCNumber = ? and IFPrefToUse = ?");
				p2.setString(1, creditcardnumber);
				p2.setString(2, prefered);
				ResultSet rs1 = p2.executeQuery();
				while (rs1.next())
				{
				wq = rs1.getString(1);
				}
			}
			}
			
			NodeList n2List = doc.getElementsByTagName("Nurse");
			for(int temp = 0; temp < n2List.getLength(); temp++)
			{
				Node n2Node = n2List.item(temp);
			
			if(n2Node.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) n2Node;
				/*System.out.println("Nurse ID : " +eElement.getElementsByTagName("NurseID").item(0).getTextContent());
				System.out.println("Nurse Cost : " +eElement.getElementsByTagName("NurseCost").item(0).getTextContent());*/
				
				Integer nid = Integer.parseInt(eElement.getElementsByTagName("NurseID").item(0).getTextContent());
				Integer ncost = Integer.parseInt(eElement.getElementsByTagName("NurseCost").item(0).getTextContent());
				CallableStatement stmt= con.prepareCall("{call qwe.n(?,?)}");
				stmt.setInt(1, nid);
				stmt.setInt(2, ncost);
				stmt.executeQuery();
				PreparedStatement p = con.prepareStatement("select N_ID from qwe.Nurse where N_ID = ? and N_Cost = ?");
				p.setInt(1, nid);
				p.setInt(2, ncost);
				ResultSet rs = p.executeQuery();
				while (rs.next())
				{
				c = rs.getInt(1);
				}
				PreparedStatement p1 = con.prepareStatement("select N_Cost from qwe.Nurse where N_ID = ?");
				p1.setInt(1, nid);
				ResultSet rs2 = p1.executeQuery();
				while (rs2.next())
				{
				nc = rs2.getInt(1);
				}
			}
			}
			
			NodeList n3List = doc.getElementsByTagName("Doctor");
			for(int temp = 0; temp < n3List.getLength(); temp++)
			{
				Node n3Node = n3List.item(temp);
			
			if(n3Node.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) n3Node;
				/*System.out.println("Doctor ID : " +eElement.getElementsByTagName("DoctorID").item(0).getTextContent());
				System.out.println("Doctor Cost : " +eElement.getElementsByTagName("DoctorCost").item(0).getTextContent());*/
				
				Integer did = Integer.parseInt(eElement.getElementsByTagName("DoctorID").item(0).getTextContent());
				Integer dcost = Integer.parseInt(eElement.getElementsByTagName("DoctorCost").item(0).getTextContent());
				CallableStatement stmt= con.prepareCall("{call qwe.d(?,?)}");
				stmt.setInt(1, did);
				stmt.setInt(2, dcost);
				stmt.executeQuery();
				PreparedStatement p = con.prepareStatement("select D_ID from qwe.Doctor where D_ID = ? and D_Cost = ?");
				p.setInt(1, did);
				p.setInt(2, dcost);
				ResultSet rs = p.executeQuery();
				while (rs.next())
				{
				x = rs.getInt(1);
				}
				PreparedStatement p1 = con.prepareStatement("select D_Cost from qwe.Doctor where D_ID = ?");
				p1.setInt(1, did);
				ResultSet rs2 = p1.executeQuery();
				while (rs2.next())
				{
				dc = rs2.getInt(1);
				}
			}
			}
			
			NodeList n4List = doc.getElementsByTagName("Room");
			for(int temp = 0; temp < n4List.getLength(); temp++)
			{
				Node n4Node = n4List.item(temp);
			
			if(n4Node.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) n4Node;
				/*System.out.println("Room ID : " +eElement.getElementsByTagName("RoomID").item(0).getTextContent());
				System.out.println("Check In Date : " +eElement.getElementsByTagName("CheckInDate").item(0).getTextContent());
				System.out.println("Discharge Date : " +eElement.getElementsByTagName("DischargeDate").item(0).getTextContent());
				System.out.println("Cost of Room Per Day : " +eElement.getElementsByTagName("RoomCostPerDay").item(0).getTextContent());*/
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd") ;
				
				String d = eElement.getElementsByTagName("CheckInDate").item(0).getTextContent();
				String e = eElement.getElementsByTagName("DischargeDate").item(0).getTextContent();
				
				java.util.Date o = dateFormat.parse(d);
				java.util.Date u = dateFormat.parse(e);
				
				java.sql.Date h = new java.sql.Date(o.getTime());
				java.sql.Date y = new java.sql.Date(u.getTime());
				
				Integer rid = Integer.parseInt(eElement.getElementsByTagName("RoomID").item(0).getTextContent());
				Integer cost = Integer.parseInt(eElement.getElementsByTagName("RoomCostPerDay").item(0).getTextContent());
				
				long f = u.getTime() - o.getTime();
				qq = TimeUnit.DAYS.convert(f,TimeUnit.MILLISECONDS);
				int rr = (int)(qq);
				dr = rr * cost;
				
				CallableStatement stmt= con.prepareCall("{call qwe.room(?,?)}");
				stmt.setInt(1, rid);
				stmt.setInt(2, cost);
				stmt.executeQuery();
				PreparedStatement p1 = con.prepareStatement("update qwe.Room set Checkindate = ? where Room_ID = ?");
				p1.setDate(1, h);
				p1.setInt(2, rid);
				p1.execute();
				PreparedStatement p2 = con.prepareStatement("update qwe.Room set Dischargedate = ? where Room_ID = ?");
				p2.setDate(1, y);
				p2.setInt(2, rid);
				p2.execute();
				PreparedStatement p = con.prepareStatement("select Room_ID from qwe.Room where Room_ID = ?");
				p.setInt(1, rid);
				ResultSet rs = p.executeQuery();
				while (rs.next())
				{
				v = rs.getInt(1);
				}
			}
			}
			
			NodeList n5List = doc.getElementsByTagName("Laboratories");
			for(int temp = 0; temp < n5List.getLength(); temp++)
			{
				Node n5Node = n5List.item(temp);
			
			if(n5Node.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) n5Node;
				/*System.out.println("Labortory ID : " +eElement.getElementsByTagName("LaboratoryID").item(0).getTextContent());
				System.out.println("Date when Lab is used : " +eElement.getElementsByTagName("TakeLabDate").item(0).getTextContent());
				System.out.println("Lab Cost : " +eElement.getElementsByTagName("LaboratoryCost").item(0).getTextContent());*/
				
				Integer lid = Integer.parseInt(eElement.getElementsByTagName("LaboratoryID").item(0).getTextContent());
				String labdate = eElement.getElementsByTagName("TakeLabDate").item(0).getTextContent();
				Integer lcost = Integer.parseInt(eElement.getElementsByTagName("LaboratoryCost").item(0).getTextContent());
				CallableStatement stmt= con.prepareCall("{call qwe.lab(?,?,?)}");
				stmt.setInt(1, lid);
				stmt.setString(2, labdate);
				stmt.setInt(3, lcost);
				stmt.executeQuery();
				PreparedStatement p1 = con.prepareStatement("update qwe.Laboratories set P_ID = ? where L_ID = ?");
				p1.setInt(1,z);
				p1.setInt(2, lid);
				p1.execute();
				PreparedStatement p = con.prepareStatement("select L_ID from qwe.Laboratories where L_ID = ? and Lab_Cost = ?");
				p.setInt(1, lid);
				p.setInt(2, lcost);
				ResultSet rs = p.executeQuery();
				while (rs.next())
				{
				k = rs.getInt(1);
				}
				PreparedStatement p2 = con.prepareStatement("select Lab_Cost from qwe.Laboratories where L_ID = ?");
				p2.setInt(1, lid);
				ResultSet rs2 = p2.executeQuery();
				while (rs2.next())
				{
				ld = rs2.getInt(1);
				}
			}
			}
			
			NodeList n6List = doc.getElementsByTagName("Radiology");
			for(int temp = 0; temp < n6List.getLength(); temp++)
			{
				Node n6Node = n6List.item(temp);
			
			if(n6Node.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) n6Node;
				/*System.out.println("Radiology ID : " +eElement.getElementsByTagName("RadiologyLabID").item(0).getTextContent());
				System.out.println("Date when Lab is used : " +eElement.getElementsByTagName("TakeradioDate").item(0).getTextContent());
				System.out.println("Lab Cost : " +eElement.getElementsByTagName("RadiologyCost").item(0).getTextContent());*/
				
				Integer rid = Integer.parseInt(eElement.getElementsByTagName("RadiologyLabID").item(0).getTextContent());
				String raddate = eElement.getElementsByTagName("TakeradioDate").item(0).getTextContent();
				Integer rcost = Integer.parseInt(eElement.getElementsByTagName("RadiologyCost").item(0).getTextContent());
				CallableStatement stmt= con.prepareCall("{call qwe.rad(?,?,?)}");
				stmt.setInt(1, rid);
				stmt.setString(2, raddate);
				stmt.setInt(3, rcost);
				stmt.executeQuery();
				PreparedStatement p1 = con.prepareStatement("update qwe.Radiology set P_ID = ? where R_ID = ?");
				p1.setInt(1,z);
				p1.setInt(2, rid);
				p1.execute();
				PreparedStatement p = con.prepareStatement("select R_Cost from qwe.Radiology where R_ID = ? and R_Cost = ?");
				p.setInt(1, rid);
				p.setInt(2, rcost);
				ResultSet rs = p.executeQuery();
				while (rs.next())
				{
				j = rs.getInt(1);
				}
				PreparedStatement p2 = con.prepareStatement("select R_Cost from qwe.Radiology where R_ID = ?");
				p2.setInt(1, rid);
				ResultSet rs2 = p.executeQuery();
				while (rs2.next())
				{
				rd = rs2.getInt(1);
				}
			}
			}
			
			NodeList n7List = doc.getElementsByTagName("Medicine");
			for(int temp = 0; temp < n7List.getLength(); temp++)
			{
				Node n7Node = n7List.item(temp);
			
			if(n7Node.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) n7Node;
				/*System.out.println("Medicine ID : " +eElement.getElementsByTagName("MedicineID").item(0).getTextContent());
				System.out.println("Threshold : " +eElement.getElementsByTagName("ThresholdInventory").item(0).getTextContent());
				System.out.println("Current Inventory amount : " +eElement.getElementsByTagName("CurrentAmount").item(0).getTextContent());
				System.out.println("Restore Reminder? : " +eElement.getElementsByTagName("RestoreReminder").item(0).getTextContent());*/
				
				Integer mid = Integer.parseInt(eElement.getElementsByTagName("MedicineID").item(0).getTextContent());
				Integer thresh = Integer.parseInt(eElement.getElementsByTagName("ThresholdInventory").item(0).getTextContent());
				Integer amount = Integer.parseInt(eElement.getElementsByTagName("CurrentAmount").item(0).getTextContent());
				String ra = eElement.getElementsByTagName("RestoreReminder").item(0).getTextContent();
				CallableStatement stmt= con.prepareCall("{call qwe.med(?,?,?,?)}");
				stmt.setInt(1, mid);
				stmt.setInt(2, thresh);
				stmt.setInt(3, amount);
				stmt.setString(4, ra);
				stmt.executeQuery();
				PreparedStatement p2 = con.prepareStatement("select M_ID from qwe.Medicine where M_ID = ?");
				p2.setInt(1, mid);
				ResultSet rs2 = p2.executeQuery();
				while (rs2.next())
				{
				md = rs2.getInt(1);
				}
			}
			}
			
			NodeList n8List = doc.getElementsByTagName("MedicinePurchase");
			for(int temp = 0; temp < n8List.getLength(); temp++)
			{
				Node n8Node = n8List.item(temp);
			
			if(n8Node.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) n8Node;
				/*System.out.println("Medicine ID : " +eElement.getElementsByTagName("MedicineID").item(0).getTextContent());
				System.out.println("Cost of a unit : " +eElement.getElementsByTagName("MedicineUnitPrice").item(0).getTextContent());
				System.out.println("Current Date : " +eElement.getElementsByTagName("MedicinePriceDate").item(0).getTextContent());
				System.out.println("Medicine Quantity : " +eElement.getElementsByTagName("MedicineAmount").item(0).getTextContent());*/
				
				Integer mid = Integer.parseInt(eElement.getElementsByTagName("MedicineID").item(0).getTextContent());
				Integer price = Integer.parseInt(eElement.getElementsByTagName("MedicineUnitPrice").item(0).getTextContent());
				String pdate = eElement.getElementsByTagName("MedicinePriceDate").item(0).getTextContent();
				Integer amount = Integer.parseInt(eElement.getElementsByTagName("MedicineAmount").item(0).getTextContent());
				
				mcost = price * amount;
				
				CallableStatement stmt= con.prepareCall("{call qwe.medp(?,?,?,?)}");
				stmt.setInt(1, mid);
				stmt.setInt(2, price);
				stmt.setString(3, pdate);
				stmt.setInt(4, amount);
				stmt.executeQuery();
				PreparedStatement p1 = con.prepareStatement("update qwe.MPurchase set P_ID = ? where M_ID = ? and M_PriceDate = ?");
				p1.setInt(1,z);
				p1.setInt(2, mid);
				p1.setString(3, pdate);
				p1.execute();
				
			}
			}
			
			NodeList n9List = doc.getElementsByTagName("PatientInsurance");
			for(int temp = 0; temp < n9List.getLength(); temp++)
			{
				Node n9Node = n9List.item(temp);
			
			if(n9Node.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) n9Node;
				/*System.out.println("Insurance Policy Number : " +eElement.getElementsByTagName("InsurancePolicyNo").item(0).getTextContent());
				System.out.println("Insurance Status : " +eElement.getElementsByTagName("InsuranceStatus").item(0).getTextContent());
				System.out.println("Coverage Percentage : " +eElement.getElementsByTagName("CoveragePercent").item(0).getTextContent());
				System.out.println("Coverage Amount : " +eElement.getElementsByTagName("CoverageAmount").item(0).getTextContent());*/
				
				String ip = eElement.getElementsByTagName("InsurancePolicyNo").item(0).getTextContent();
				String status = eElement.getElementsByTagName("InsuranceStatus").item(0).getTextContent();
				Integer cp = Integer.parseInt(eElement.getElementsByTagName("CoveragePercent").item(0).getTextContent());
				Integer amount = Integer.parseInt(eElement.getElementsByTagName("CoverageAmount").item(0).getTextContent());
				CallableStatement stmt= con.prepareCall("{call qwe.ipp(?,?,?,?)}");
				stmt.setString(1, ip);
				stmt.setString(2, status);
				stmt.setInt(3, cp);
				stmt.setInt(4, amount);
				stmt.executeQuery();
				PreparedStatement p1 = con.prepareStatement("update qwe.PI set P_ID = ? where IP_Number = ?");
				p1.setInt(1,z);
				p1.setString(2,ip);
				p1.execute();
				
				PreparedStatement p2 = con.prepareStatement("select IP_Status from qwe.PI where P_ID = ? and IP_Number = ?");
				p2.setInt(1, z);
				p2.setString(2, ip);
				ResultSet rs2 = p2.executeQuery();
				while (rs2.next())
				{
				pp = rs2.getString(1);
				}
				
				PreparedStatement p3 = con.prepareStatement("select CoveragePercantage from qwe.PI where P_ID = ? and IP_Number = ?");
				p3.setInt(1, z);
				p3.setString(2, ip);
				ResultSet rs3 = p3.executeQuery();
				while (rs3.next())
				{
				cp1 = rs3.getInt(1);
				}
			}
			}
			
			NodeList n10List = doc.getElementsByTagName("Bill");
			for(int temp = 0; temp < n10List.getLength(); temp++)
			{
				Node n10Node = n10List.item(temp);
			
			if(n10Node.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) n10Node;
				/*System.out.println("Bill Date : " +eElement.getElementsByTagName("BillDate").item(0).getTextContent());
				System.out.println("Bill Paid ? : " +eElement.getElementsByTagName("IfPaid").item(0).getTextContent());*/
		
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd") ;
				String d = eElement.getElementsByTagName("BillDate").item(0).getTextContent();
				java.util.Date o = dateFormat.parse(d);
				java.sql.Date bd = new java.sql.Date(o.getTime());
				
				String bp = eElement.getElementsByTagName("IfPaid").item(0).getTextContent();
			
				CallableStatement stmt= con.prepareCall("{call qwe.b(cast (? as date),?)}");
				stmt.setDate(1, bd);
				stmt.setString(2, bp);
				stmt.executeQuery();
				
				PreparedStatement p1 = con.prepareStatement("update qwe.Bill set P_ID = ? where Bill_Date = cast (? as date) and If_paid = ?");
				p1.setInt(1,z);
				p1.setDate(2, bd);
				p1.setString(3, bp);
				p1.execute();
				
				PreparedStatement p = con.prepareStatement("select Bill_ID from qwe.Bill where P_ID = ? and Bill_Date = cast (? as date)");
				p.setInt(1, z);
				p.setDate(2, bd);
				ResultSet rs = p.executeQuery();
				while (rs.next())
				{
				q = rs.getInt(1);
				}
				
				PreparedStatement p2 = con.prepareStatement("update qwe.Bill set N_ID = ? where P_ID = ? and Bill_Date = cast (? as date)");
				p2.setInt(1, c);
				p2.setInt(2, z);
				p2.setDate(3, bd);
				p2.execute();
				PreparedStatement p3 = con.prepareStatement("update qwe.Bill set D_ID = ? where P_ID = ? and Bill_Date = cast (? as date)");
				p3.setInt(1, x);
				p3.setInt(2, z);
				p3.setDate(3, bd);
				p3.execute();
				PreparedStatement p4 = con.prepareStatement("update qwe.Bill set Room_ID = ? where P_ID = ? and Bill_Date = cast (? as date)");
				p4.setInt(1, v);
				p4.setInt(2, z);
				p4.setDate(3, bd);
				p4.execute();
				PreparedStatement p5 = con.prepareStatement("update qwe.Bill set L_ID = ? where P_ID = ? and Bill_Date = cast (? as date)");
				p5.setInt(1, k);
				p5.setInt(2, z);
				p5.setDate(3, bd);
				p5.execute();
				PreparedStatement p6 = con.prepareStatement("update qwe.Bill set R_ID = ? where P_ID = ? and Bill_Date = cast (? as date)");
				p6.setInt(1, j);
				p6.setInt(2, z);
				p6.setDate(3, bd);
				p6.execute();
				PreparedStatement p7 = con.prepareStatement("update qwe.Bill set Doctor_Cost = ? where P_ID = ? and Bill_Date = cast (? as date)");
				p7.setInt(1, dc);
				p7.setInt(2, z);
				p7.setDate(3, bd);
				p7.execute();
				PreparedStatement p8 = con.prepareStatement("update qwe.Bill set Nurse_Cost = ? where P_ID = ? and Bill_Date = cast (? as date)");
				p8.setInt(1, nc);
				p8.setInt(2, z);
				p8.setDate(3, bd);
				p8.execute();
				PreparedStatement p9 = con.prepareStatement("update qwe.Bill set Lab_Cost = ? where P_ID = ? and Bill_Date = cast (? as date)");
				p9.setInt(1, ld);
				p9.setInt(2, z);
				p9.setDate(3, bd);
				p9.execute();
				PreparedStatement p10 = con.prepareStatement("update qwe.Bill set Radiology_Cost = ? where P_ID = ? and Bill_Date = cast (? as date)");
				p10.setInt(1, rd);
				p10.setInt(2, z);
				p10.setDate(3, bd);
				p10.execute();
				PreparedStatement p11 = con.prepareStatement("update qwe.Bill set CreditCardName = ? where P_ID = ? and Bill_Date = cast (? as date)");
				p11.setString(1, qw);
				p11.setInt(2, z);
				p11.setDate(3, bd);
				p11.execute();
				PreparedStatement p12 = con.prepareStatement("update qwe.Bill set BillAddress = ? where P_ID = ? and Bill_Date = cast (? as date)");
				p12.setString(1, wq);
				p12.setInt(2, z);
				p12.setDate(3, bd);
				p12.execute();
				PreparedStatement p13= con.prepareStatement("update qwe.Bill set Room_Cost = ? where P_ID = ? and Bill_Date = cast(? as date)");
				p13.setInt(1, dr);
				p13.setInt(2, z);
				p13.setDate(3, bd);
				p13.execute();
				PreparedStatement p14= con.prepareStatement("update qwe.Bill set Medicine_Cost = ? where P_ID = ? and Bill_Date = cast(? as date)");
				p14.setInt(1, mcost);
				p14.setInt(2, z);
				p14.setDate(3, bd);
				p14.execute();
				
				Calendar ccc = Calendar.getInstance();
				ccc.setTime(o);
				ccc.add(Calendar.MONTH, 3);
				Date nd = ccc.getTime();
				String nd1 = dateFormat.format(nd);
				java.util.Date o1 = dateFormat.parse(nd1);
				java.sql.Date bd1 = new java.sql.Date(o1.getTime());
				
				PreparedStatement p15= con.prepareStatement("update qwe.Bill set First_Due_Date = cast(? as date) where P_ID = ? and Bill_Date = cast(? as date)");
				p15.setDate(1, bd1);
				p15.setInt(2, z);
				p15.setDate(3, bd);
				p15.execute();
				
				int total = (dc + nc + ld + rd + dr + mcost);
				PreparedStatement p16= con.prepareStatement("update qwe.Bill set Total_Bill = ? where P_ID = ? and Bill_Date = cast(? as date)");
				p16.setInt(1, total);
				p16.setInt(2, z);
				p16.setDate(3, bd);
				p16.execute();
				
				int Balance = total - (total * cp1/100);
	
				String pp1 = pp;
				if(pp == pp1)
				{
					PreparedStatement p17= con.prepareStatement("update qwe.Bill set Balance_Amount = ? where P_ID = ? and Bill_Date = cast(? as date)");
					p17.setInt(1, Balance);
					p17.setInt(2, z);
					p17.setDate(3, bd);
					p17.execute();
				}
				else
				{
					PreparedStatement p17= con.prepareStatement("update qwe.Bill set Balance_Amount = ? where P_ID = ? and Bill_Date = cast(? as date)");
					p17.setInt(1, total);
					p17.setInt(2, z);
					p17.setDate(3, bd);
					p17.execute();
				}
				if(Balance == 0)
				{
					String yy = "Yes";
					PreparedStatement p18= con.prepareStatement("update qwe.Bill set If_paid = ? where P_ID = ? and Bill_Date = cast(? as date)");
					p18.setString(1, yy);
					p18.setInt(2, z);
					p18.setDate(3, bd);
					p18.execute();
				}
				Object[][] rows = {
						{q,bd,z,dc,nc,dr,ld,rd,qw,bd1,wq,mcost,bp}
				};
				Object[] cols = {
						"BillID","BillDate","PatientID","DoctorCost","NurseCost","RoomCost","LabCost","RadiologyCost","CreditCardNumber","FirstDueDate","BillAddress","MedicineCost","IfPaid"
				};
				JTable table = new JTable(rows,cols);
				JOptionPane.showMessageDialog(null,new JScrollPane(table));
				//JFrame frame = new JFrame("Bill");
				//JOptionPane.showMessageDialog(frame, "Billing Table"+"\n"
				//									+"BillID	BillDate	PatientID	DoctorCost	NurseCost	RoomCost	LabCost			RadiologyCost		CreditCardNumber	FirstDueDate	BillAddress		MedicineCost		IfPaid"
				//									+q+"		"+o+"		"+z+"		"+dc+"		"+nc+"		"+dr+"		"+ld+"		"+rd+"		"+qw+"		"+o1+"		"+wq+"		"+mcost+	"		"+bp);
			}
			}
			
			NodeList n11List = doc.getElementsByTagName("Inquiry");
			for(int temp = 0; temp < n11List.getLength(); temp++)
			{
				Node n11Node = n11List.item(temp);
			
			if(n11Node.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) n11Node;
				//System.out.println("Inquiry Date : " +eElement.getElementsByTagName("InquiryDate").item(0).getTextContent());
				
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd") ;
				String id = eElement.getElementsByTagName("InquiryDate").item(0).getTextContent();
				java.util.Date o = dateFormat.parse(id);
				java.sql.Date bd = new java.sql.Date(o.getTime());
				
				CallableStatement stmt= con.prepareCall("{call qwe.in(cast (? as date))}");
				stmt.setDate(1, bd);
				stmt.executeQuery();
				PreparedStatement p1 = con.prepareStatement("update qwe.Inquiry set P_ID = ? where Inquiry_Date = cast(? as date)");
				p1.setInt(1,z);
				p1.setDate(2, bd);
				p1.execute();
				PreparedStatement p2 = con.prepareStatement("update qwe.Inquiry set Bill_ID = ? where Inquiry_Date = cast(? as date)");
				p2.setInt(1, q);
				p2.setDate(2, bd);
				p2.execute();
				PreparedStatement p = con.prepareStatement("select Inquiry_ID from qwe.Inquiry where Inquiry_Date = ? and P_ID = ?");
				p.setDate(1, bd);
				p.setInt(2, z);
				ResultSet rs = p.executeQuery();
				while (rs.next())
				{
				ii = rs.getInt(1);
				}
				
				Object[][] rows = {
						{ii,z,bd,q}
				};
				Object[] cols = {
						"InquiryID","PatientID","InquiryDate","BillID"
				};
				JTable table = new JTable(rows,cols);
				JOptionPane.showMessageDialog(null,new JScrollPane(table));
			}
			}
			PreparedStatement p = con.prepareStatement("select Reminder_ID from qwe.BillReminder");
			ResultSet rs = p.executeQuery();
			while (rs.next())
			{
			ri = rs.getInt(1);
			}
			PreparedStatement p1 = con.prepareStatement("select Billing_Reminder_Record from qwe.BillReminder where Reminder_ID = ?");
			p1.setInt(1, ri);
			ResultSet rs1 = p1.executeQuery();
			while (rs1.next())
			{
			rrr = rs1.getString(1);
			}
			
			Object[][] rows = {
					{ri,rrr}
			};
			Object[] cols = {
					"BillingReminderID","BillingReminderRecord"
			};
			JTable table = new JTable(rows,cols);
			JOptionPane.showMessageDialog(null,new JScrollPane(table));
		
			PreparedStatement p2 = con.prepareStatement("select Current_Amount from qwe.Medicine where M_ID = ?");
			p2.setInt(1, md);
			ResultSet rs2 = p2.executeQuery();
			while (rs2.next())
			{
			ca = rs2.getInt(1);
			}
			PreparedStatement p3 = con.prepareStatement("select Threshold from qwe.Medicine where M_ID = ?");
			p3.setInt(1, md);
			ResultSet rs3 = p3.executeQuery();
			while (rs3.next())
			{
			tt = rs3.getInt(1);
			}
			PreparedStatement p4 = con.prepareStatement("select RestoreReminder from qwe.Medicine where M_ID = ?");
			p4.setInt(1, md);
			ResultSet rs4 = p4.executeQuery();
			while (rs4.next())
			{
			rrrr = rs4.getString(1);
			}
		

			Object[][] rows1 = {
					{md,ca,tt,rrrr}
			};
			Object[] cols1 = {
					"MedicineID","CurrentAmount","ThresholdInventory","RestoreReminder"
			};
			JTable table1 = new JTable(rows1,cols1);
			JOptionPane.showMessageDialog(null,new JScrollPane(table1));
		}
		catch(Exception e)
 		{
			System.out.println(e);
		}
	}
	}