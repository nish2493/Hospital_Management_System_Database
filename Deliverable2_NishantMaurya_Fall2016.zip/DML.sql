
-- ----------------------------
-- Records of Patient
-- ----------------------------
INSERT INTO "abc"."Patients" ("P_FirstName", "P_LastName", "P_MiddleName","P_DOB") VALUES ('Nishant', 'Maurya', 'Ramesh', '1993-08-24');
INSERT INTO "abc"."Patients" ("P_FirstName", "P_LastName", "P_MiddleName","P_DOB") VALUES ('Aniket', 'Jangam', 'Shivaji', '1992-09-09');
INSERT INTO "abc"."Patients" ("P_FirstName", "P_LastName", "P_MiddleName","P_DOB") VALUES ('Mohammed', 'Esoofally', 'Z', '1993-11-22');
INSERT INTO "abc"."Patients" ("P_FirstName", "P_LastName", "P_MiddleName","P_DOB") VALUES ('Aditya', 'Jain', 'XYZ', '1990-07-05');
INSERT INTO "abc"."Patients" ("P_FirstName", "P_LastName", "P_MiddleName","P_DOB") VALUES ('Chirag', 'Padsala', 'ABC', '1993-04-10');


-- ----------------------------
-- Records of Credit_Card_Details
-- ----------------------------
INSERT INTO "abc"."CCDetails" ( "CC_Number" ,"Address", "Phone_Number", "P_ID", "CVV") VALUES ('12345678', 'dfdgsg', '4546463535', '1', '345');
INSERT INTO "abc"."CCDetails" ( "CC_Number" ,"Address", "Phone_Number", "P_ID", "CVV") VALUES ('23456789', 'enfnffndq', '8453858385', '2', '765');
INSERT INTO "abc"."CCDetails" ( "CC_Number" ,"Address", "Phone_Number", "P_ID", "CVV") VALUES ('87654321', 'rsgewtwet', '2343424422', '4', '872');
INSERT INTO "abc"."CCDetails" ( "CC_Number" ,"Address", "Phone_Number", "P_ID", "CVV") VALUES ('98765432', 'fgggdfg', '3435352253', '3', '909');
INSERT INTO "abc"."CCDetails" ( "CC_Number" ,"Address", "Phone_Number", "P_ID", "CVV") VALUES ('876543219', 'dfdffsa', '1234567891', '5', '123');


-- ----------------------------
-- Records of Login
-- ----------------------------
INSERT INTO "abc"."LoginDetails" ( "P_ID" ,"P_EmailAddress", "P_Password") VALUES ('1', 'nish2493@rocketmail.com', 'nishant');
INSERT INTO "abc"."LoginDetails" ( "P_ID" ,"P_EmailAddress", "P_Password") VALUES ('2', 'abc@yahoo.com', 'abc');
INSERT INTO "abc"."LoginDetails" ( "P_ID" ,"P_EmailAddress", "P_Password") VALUES ('3', 'xyz@gmail.com', 'xyz');
INSERT INTO "abc"."LoginDetails" ( "P_ID" ,"P_EmailAddress", "P_Password") VALUES ('4', 'pqr@yahoo.com', 'pqr');
INSERT INTO "abc"."LoginDetails" ( "P_ID" ,"P_EmailAddress", "P_Password") VALUES ('5', 'asd@tmail.com', 'asd');


-- ----------------------------
-- Records of Doctor
-- ----------------------------
INSERT INTO "abc"."Doctors" ( "D_FirstName" ,"D_MiddleName", "D_LastName", "D_Fees", "Discipline", "D_PhoneNumber") VALUES ('Nishant', 'Ramesh', 'Maurya', '60.00', 'MBBS', '83837357374');
INSERT INTO "abc"."Doctors" ( "D_FirstName" ,"D_MiddleName", "D_LastName", "D_Fees", "Discipline", "D_PhoneNumber") VALUES ('abc', 'b', 'c', '60.00', 'Mbbs', '4385359735');
INSERT INTO "abc"."Doctors" ( "D_FirstName" ,"D_MiddleName", "D_LastName", "D_Fees", "Discipline", "D_PhoneNumber") VALUES ('pqr', 'q', 'r', '50.00', 'mbbs', '33535353535');
INSERT INTO "abc"."Doctors" ( "D_FirstName" ,"D_MiddleName", "D_LastName", "D_Fees", "Discipline", "D_PhoneNumber") VALUES ('asd', 's', 'd', '40.00', 'mbbs', '45353535353');
INSERT INTO "abc"."Doctors" ( "D_FirstName" ,"D_MiddleName", "D_LastName", "D_Fees", "Discipline", "D_PhoneNumber") VALUES ('xyz', 'y', 'z', '38.00', 'mbbs', '385834835835');


-- ----------------------------
-- Records of Nurse
-- ----------------------------
INSERT INTO "abc"."Nurses" ( "N_FirstName" ,"N_MiddleName", "N_LastName", "N_PhoneNumber", "N_Address") VALUES ('abc', 'b', 'c', '8686868342', 'hjjkbj');
INSERT INTO "abc"."Nurses" ( "N_FirstName" ,"N_MiddleName", "N_LastName", "N_PhoneNumber", "N_Address") VALUES ('pqr', 'q', 'r', '9398498394', 'hdfhdskhf');
INSERT INTO "abc"."Nurses" ( "N_FirstName" ,"N_MiddleName", "N_LastName", "N_PhoneNumber", "N_Address") VALUES ('xyz', 'y', 'z', '3799394739', 'dfdsf');
INSERT INTO "abc"."Nurses" ( "N_FirstName" ,"N_MiddleName", "N_LastName", "N_PhoneNumber", "N_Address") VALUES ('asd', 's', 'd', '3394793479', 'dhfjdhf');
INSERT INTO "abc"."Nurses" ( "N_FirstName" ,"N_MiddleName", "N_LastName", "N_PhoneNumber", "N_Address") VALUES ('zxc', 'x', 'c', '3793497349', 'dfkdfkh');


-- ----------------------------
-- Records of Receptionist
-- ----------------------------
INSERT INTO "abc"."Reception" ( "R_FirstName" ,"R_LastName", "R_Address", "R_PhoneNumber") VALUES ('Nishant', 'Maurya', 'dsfsf', '398894934');
INSERT INTO "abc"."Reception" ( "R_FirstName" ,"R_LastName", "R_Address", "R_PhoneNumber") VALUES ('abc', 'c', 'asjdkajf', '398498349');
INSERT INTO "abc"."Reception" ( "R_FirstName" ,"R_LastName", "R_Address", "R_PhoneNumber") VALUES ('xyz', 'z', 'aefhhf', '394934934');
INSERT INTO "abc"."Reception" ( "R_FirstName" ,"R_LastName", "R_Address", "R_PhoneNumber") VALUES ('pqr', 'r', 'sjbfjfbk', '343840834');
INSERT INTO "abc"."Reception" ( "R_FirstName" ,"R_LastName", "R_Address", "R_PhoneNumber") VALUES ('asd', 'd', 'efsfsef', '344342342');


-- ----------------------------
-- Records of Rooms
-- ----------------------------
INSERT INTO "abc"."Room" ( "Room_Number" ,"Room_Cost", "Room_Available") VALUES ('203', '2000.00', 't');
INSERT INTO "abc"."Room" ( "Room_Number" ,"Room_Cost", "Room_Available") VALUES ('303', '2500.00', 'f');
INSERT INTO "abc"."Room" ( "Room_Number" ,"Room_Cost", "Room_Available") VALUES ('102', '2000.00', 't');
INSERT INTO "abc"."Room" ( "Room_Number" ,"Room_Cost", "Room_Available") VALUES ('402', '3000.00', 'f');
INSERT INTO "abc"."Room" ( "Room_Number" ,"Room_Cost", "Room_Available") VALUES ('343', '5000.00', 't');


-- ----------------------------
-- Records of Appointment
-- ----------------------------
INSERT INTO "abc"."Appointments" ( "R_ID" ,"P_ID", "D_ID", "Services", "App_Date", "App_On_Date") VALUES ('1', '1', '1', 'General Appointment', '2016-09-24', null);
INSERT INTO "abc"."Appointments" ( "R_ID" ,"P_ID", "D_ID", "Services", "App_Date", "App_On_Date") VALUES ('2', '2', '1', 'General appointment', '2016-09-25', null);
INSERT INTO "abc"."Appointments" ( "R_ID" ,"P_ID", "D_ID", "Services", "App_Date", "App_On_Date") VALUES ('5', '5', '4', 'abc', '2016-09-13', null);
INSERT INTO "abc"."Appointments" ( "R_ID" ,"P_ID", "D_ID", "Services", "App_Date", "App_On_Date") VALUES ('3', '1', '3', 'qrw', '2016-10-06', null);
INSERT INTO "abc"."Appointments" ( "R_ID" ,"P_ID", "D_ID", "Services", "App_Date", "App_On_Date") VALUES ('4', '3', '2', 'fdfd', '2016-10-05', null);

-- ----------------------------
-- Records of Admits
-- ----------------------------
INSERT INTO "abc"."Admits" ("P_ID", "N_ID", "Room_ID", "Adm_Date", "DischargeDate","Cost_Of_Room") VALUES ('1', '2', '3', '2016-10-04', null, '42242');
INSERT INTO "abc"."Admits" ("P_ID", "N_ID", "Room_ID", "Adm_Date", "DischargeDate","Cost_Of_Room") VALUES ('3', '2', '4', '2016-10-21', null, '524');
INSERT INTO "abc"."Admits" ("P_ID", "N_ID", "Room_ID", "Adm_Date", "DischargeDate","Cost_Of_Room") VALUES ('5', '1', '5', '2016-10-02', null, '24242');
INSERT INTO "abc"."Admits" ("P_ID", "N_ID", "Room_ID", "Adm_Date", "DischargeDate","Cost_Of_Room") VALUES ('4', '5', '1', '2016-10-26', null, '245252');
INSERT INTO "abc"."Admits" ("P_ID", "N_ID", "Room_ID", "Adm_Date", "DischargeDate","Cost_Of_Room") VALUES ('2', '3', '4', '2016-10-11', null, '25225');

-- ----------------------------
-- Records of Insurance_policy
-- ----------------------------
INSERT INTO "abc"."I_P" ("P_ID", "IP_Coverage", "IP_Company", "IP_CoveragePrecentage") VALUES ('1', '4500', 'jdfdj', '70');
INSERT INTO "abc"."I_P" ("P_ID", "IP_Coverage", "IP_Company", "IP_CoveragePrecentage") VALUES ('2', '5000', 'hjbg', '80');
INSERT INTO "abc"."I_P" ("P_ID", "IP_Coverage", "IP_Company", "IP_CoveragePrecentage") VALUES ('3', '7000', 'hdfj', '88');
INSERT INTO "abc"."I_P" ("P_ID", "IP_Coverage", "IP_Company", "IP_CoveragePrecentage") VALUES ('4', '15000', 'jfj', '100');
INSERT INTO "abc"."I_P" ("P_ID", "IP_Coverage", "IP_Company", "IP_CoveragePrecentage") VALUES ('5', '4899', 'hrr', '95');


-- ----------------------------
-- Records of Accountant
-- ----------------------------
INSERT INTO "abc"."Accountants" ("IP_PolicyNumber", "A_Name", "A_Address", "A_PhoneNumber") VALUES ('2', 'abc', 'Miami', '453535353');
INSERT INTO "abc"."Accountants" ("IP_PolicyNumber", "A_Name", "A_Address", "A_PhoneNumber") VALUES ('4', 'xyz', 'Miami', '354655746');
INSERT INTO "abc"."Accountants" ("IP_PolicyNumber", "A_Name", "A_Address", "A_PhoneNumber") VALUES ('1', 'pqr', 'Miami', '464757557');
INSERT INTO "abc"."Accountants" ("IP_PolicyNumber", "A_Name", "A_Address", "A_PhoneNumber") VALUES ('3', 'asd', 'Miami', '868675646');
INSERT INTO "abc"."Accountants" ("IP_PolicyNumber", "A_Name", "A_Address", "A_PhoneNumber") VALUES ('5', 'tfg', 'Miami', '676867564');


-- ----------------------------
-- Records of Diagnosis
-- ----------------------------
INSERT INTO "abc"."Diag" ("App_ID", "D_ID", "P_ID", "Daig_Fees") VALUES ('1', '3', '4', '45.00');
INSERT INTO "abc"."Diag" ("App_ID", "D_ID", "P_ID", "Daig_Fees") VALUES ('3', '4', '2', '35.00');
INSERT INTO "abc"."Diag" ("App_ID", "D_ID", "P_ID", "Daig_Fees") VALUES ('2', '4', '1', '34.00');
INSERT INTO "abc"."Diag" ("App_ID", "D_ID", "P_ID", "Daig_Fees") VALUES ('5', '1', '3', '35.00');
INSERT INTO "abc"."Diag" ("App_ID", "D_ID", "P_ID", "Daig_Fees") VALUES ('4', '2', '2', '353.00');


-- ----------------------------
-- Records of Medicine
-- ----------------------------
INSERT INTO "abc"."Medicines" VALUES ('dgd', 'C:\Users\nish2\OneDrive\Pictures\Saved Pictures\Medicine1', '34.00');
INSERT INTO "abc"."Medicines" VALUES ('dfdgd', 'C:\Users\nish2\OneDrive\Pictures\Saved Pictures\Medicine1', '64.00');
INSERT INTO "abc"."Medicines" VALUES ('efef', 'C:\Users\nish2\OneDrive\Pictures\Saved Pictures\Medicine1', '75.00');
INSERT INTO "abc"."Medicines" VALUES ('efe2', 'C:\Users\nish2\OneDrive\Pictures\Saved Pictures\Medicine1', '45.00');
INSERT INTO "abc"."Medicines" VALUES ('dssgdg', 'C:\Users\nish2\OneDrive\Pictures\Saved Pictures\Medicine1', '34.00');


-- ----------------------------
-- Records of M_Type
-- ----------------------------
INSERT INTO "abc"."Medicine_Type" VALUES ('no  ','yes', '4');
INSERT INTO "abc"."Medicine_Type" VALUES ('no  ','yes', '2');
INSERT INTO "abc"."Medicine_Type" VALUES ('yes ','no', '1');
INSERT INTO "abc"."Medicine_Type" VALUES ('yes ','no', '3');
INSERT INTO "abc"."Medicine_Type" VALUES ('yes ','no', '5');


-- ----------------------------
-- Records of M_Type1
-- ----------------------------
INSERT INTO "abc"."Medicine_Type1" VALUES ('no', '2');
INSERT INTO "abc"."Medicine_Type1" VALUES ('no', '4');
INSERT INTO "abc"."Medicine_Type1" VALUES ('no', '5');
INSERT INTO "abc"."Medicine_Type1" VALUES ('yes', '1');
INSERT INTO "abc"."Medicine_Type1" VALUES ('yes', '3');


-- ----------------------------
-- Records of M_Type2
-- ----------------------------
INSERT INTO "abc"."Medicine_Type2" VALUES ('no', '1');
INSERT INTO "abc"."Medicine_Type2" VALUES ('no', '2');
INSERT INTO "abc"."Medicine_Type2" VALUES ('no', '3');
INSERT INTO "abc"."Medicine_Type2" VALUES ('no', '4');
INSERT INTO "abc"."Medicine_Type2" VALUES ('no', '5');


-- ----------------------------
-- Records of M_Type3
-- ----------------------------
INSERT INTO "abc"."Medicine_Type3" VALUES ('no', 'yes', '3');
INSERT INTO "abc"."Medicine_Type3" VALUES ('no ', 'yes', '4');
INSERT INTO "abc"."Medicine_Type3" VALUES ('yes', 'no', '1');
INSERT INTO "abc"."Medicine_Type3" VALUES ('yes', 'no', '2');
INSERT INTO "abc"."Medicine_Type3" VALUES ('yes ', 'no', '5');


-- ----------------------------
-- Records of Prescription
-- ----------------------------
INSERT INTO "abc"."Presc" ("P_ID", "D_ID", "App_ID", "Presc_Fees", "M_ID") VALUES ('1', '1', '1', '23.00', '3');
INSERT INTO "abc"."Presc" ("P_ID", "D_ID", "App_ID", "Presc_Fees", "M_ID") VALUES ('2', '2', '1', '3.00', '2');
INSERT INTO "abc"."Presc" ("P_ID", "D_ID", "App_ID", "Presc_Fees", "M_ID") VALUES ('3', '3', '3', '34.00', '1');
INSERT INTO "abc"."Presc" ("P_ID", "D_ID", "App_ID", "Presc_Fees", "M_ID") VALUES ('3', '4', '5', '25.00', '4');
INSERT INTO "abc"."Presc" ("P_ID", "D_ID", "App_ID", "Presc_Fees", "M_ID") VALUES ('2', '5', '3', '464.00', '5');


-- ----------------------------
-- Records of Records
-- ----------------------------
INSERT INTO "abc"."Patient_Records" VALUES ('1', '1', '1', '16:39:11', '66.45', '11-23', '98');
INSERT INTO "abc"."Patient_Records" VALUES ('1', '2', '2', '16:40:01', '56', '134', '97');
INSERT INTO "abc"."Patient_Records" VALUES ('5','4', '5', '21:40:31', '77', '453', '98');
INSERT INTO "abc"."Patient_Records" VALUES ('4','3', '2', '20:41:02', '45', '565', '95');
INSERT INTO "abc"."Patient_Records" VALUES ('3','1', '4', '18:41:32', '89', '453', '99');


-- ----------------------------
-- Records of Supplier
-- ----------------------------
INSERT INTO "abc"."Suppliers" ("S_Name", "S_Address", "DiscountPercentage") VALUES ('dfgf', 'sgdg', '50');
INSERT INTO "abc"."Suppliers" ("S_Name", "S_Address", "DiscountPercentage") VALUES ('rgdrg', 'dfgdf', '80');
INSERT INTO "abc"."Suppliers" ("S_Name", "S_Address", "DiscountPercentage") VALUES ('sgd', 'dfgdf', '40');
INSERT INTO "abc"."Suppliers" ("S_Name", "S_Address", "DiscountPercentage") VALUES ('dgd', 'sd', '30');
INSERT INTO "abc"."Suppliers" ("S_Name", "S_Address", "DiscountPercentage") VALUES ('sgs', 'ew', '20');


-- ----------------------------
-- Records of Supplier_Supplies_Medicine
-- ----------------------------
INSERT INTO "abc"."SSMedicine" VALUES ('1', '2', 'fd', '56.00');
INSERT INTO "abc"."SSMedicine" VALUES ('1', '2', 'fd', '56.00');
INSERT INTO "abc"."SSMedicine" VALUES ('2', '1', 'fe', '65.00');
INSERT INTO "abc"."SSMedicine" VALUES ('4', '4', 'efet', '134.00');
INSERT INTO "abc"."SSMedicine" VALUES ('5', '3', 'etj', '33.00');


-- ----------------------------
-- Records of Tests
-- ----------------------------
INSERT INTO "abc"."Test" ("Test_Type", "Test_Fee", "D_ID", "App_ID") VALUES ('7', '27.00', '4', '2');
INSERT INTO "abc"."Test" ("Test_Type", "Test_Fee", "D_ID", "App_ID") VALUES ('hhk', '78.00', '3', '3');
INSERT INTO "abc"."Test" ("Test_Type", "Test_Fee", "D_ID", "App_ID") VALUES ('hjh', '89.00', '3', '3');
INSERT INTO "abc"."Test" ("Test_Type", "Test_Fee", "D_ID", "App_ID") VALUES ('hkd', '3.00', '2', '3');
INSERT INTO "abc"."Test" ("Test_Type", "Test_Fee", "D_ID", "App_ID") VALUES ('kkn', '89.00', '3', '1');


-- ----------------------------
-- Records of Billing
-- ----------------------------
INSERT INTO "abc"."Bills" ("B_Amount", "B_Date", "B_DueDate", "D_ID", "P_ID", "Test_ID", "Diag_ID", "Presc_ID", "Adm_ID") VALUES ('4573', '2016-09-24', '2016-11-01', '1', '1', '3', '4', '1', '2');
INSERT INTO "abc"."Bills" ("B_Amount", "B_Date", "B_DueDate", "D_ID", "P_ID", "Test_ID", "Diag_ID", "Presc_ID", "Adm_ID") VALUES ('6452', '2016-09-24', '2016-11-01', '3', '2', '1', '4', '5', '3');
INSERT INTO "abc"."Bills" ("B_Amount", "B_Date", "B_DueDate", "D_ID", "P_ID", "Test_ID", "Diag_ID", "Presc_ID", "Adm_ID") VALUES ('7464', '2016-10-01', '2016-12-15', '5', '1', '3', '4', '1', '4');
INSERT INTO "abc"."Bills" ("B_Amount", "B_Date", "B_DueDate", "D_ID", "P_ID", "Test_ID", "Diag_ID", "Presc_ID", "Adm_ID") VALUES ('4745', '2016-09-29', '2016-12-29', '4', '5', '2', '2', '5', '1');
INSERT INTO "abc"."Bills" ("B_Amount", "B_Date", "B_DueDate", "D_ID", "P_ID", "Test_ID", "Diag_ID", "Presc_ID", "Adm_ID") VALUES ('7353', '2016-09-28', '2016-12-30', '2', '3', '4', '1', '2', null);

