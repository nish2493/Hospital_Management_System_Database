CREATE FUNCTION "abc"."Patients_insert"(
IN P_FirstName varchar(255),
IN P_LastName varchar(255),
IN P_MiddleName varchar(255),
IN P_DOB DATE, 
OUT PSeq INTEGER)

AS $$

BEGIN

 insert into "abc"."Patients"("P_FirstName","P_LastName","P_MiddleName","P_DOB") values ($1,$2,$3,$4);

 select ("P_ID") into PSeq from "abc"."Patients" p where p."P_FirstName"=$1 and p."P_LastName"=$2;

END;
$$
Language plpgsql;
 
select "abc"."Patients_insert"('Nishant','Maurya','Ramesh','1993-08-24');

CREATE FUNCTION "abc"."Patients_update"(in "P_FirstName" varchar(255),in "P_LastName" varchar(255)) RETURNS void AS $$

    update "abc"."Patients" set "P_MiddleName"=md5('$2')

        WHERE "P_LastName"=$1;

$$

LANGUAGE SQL;

CREATE FUNCTION "abc"."Patients_delete"(in "P_FirstName" varchar(255),in "P_LastName" varchar(255)) RETURNS void AS $$

    delete "abc"."Patients" set "P_MiddleName"=md5('$2')

        WHERE "P_LastName"=$1;

$$

LANGUAGE SQL;


CREATE FUNCTION "abc"."Doctors_insert"(
IN D_FirstName varchar(255),
IN D_MiddleName varchar(255),
IN D_LastName varchar(255),
IN D_Fees numeric(10,2), 
IN Discipline varchar(255), 
IN D_PhoneNumber int8, 
OUT DSeq INTEGER)

AS $$

BEGIN

 insert into "abc"."Doctors"("D_FirstName","D_MiddleName","D_LastName","D_Fees","Discipline","D_PhoneNumber") values ($1,$2,$3,$4,$5,$6);

 select ("D_ID") into DSeq from "abc"."Doctors" d where d."D_FirstName"=$1 and d."D_LastName"=$3;

END;
$$
Language plpgsql;

select "abc"."Doctors_insert"('Nishant','Maurya','Ramesh',4545,'abc',45646454);




CREATE FUNCTION "abc"."Nurses_insert"(
IN N_FirstName varchar(255),
IN N_MiddleName varchar(255),
IN N_LastName varchar(255),  
IN N_PhoneNumber int8, 
IN N_Address varchar(255),
OUT NSeq INTEGER)

AS $$

BEGIN

 insert into "abc"."Nurses"("N_FirstName","N_MiddleName","N_LastName","N_PhoneNumber","N_Address") values ($1,$2,$3,$4,$5);

 select ("N_ID") into NSeq from "abc"."Nurses" n where n."N_FirstName"=$1 and n."N_LastName"=$3;

END;
$$
Language plpgsql;


select "abc"."Nurses_insert"('Nishant','Maurya','Ramesh',454646454,'1993-08-24');



CREATE FUNCTION "abc"."Nurses_update"(in "N_FirstName" varchar(255),in "N_LastName" varchar(255)) RETURNS void AS $$

    update "abc"."Nurses" set "N_MiddleName"=md5('$2')

        WHERE "N_LastName"=$1;

$$

LANGUAGE SQL;

CREATE FUNCTION "abc"."Nurses_delete"(in "N_FirstName" varchar(255),in "N_LastName" varchar(255)) RETURNS void AS $$

    delete "abc"."Nurses" set "N_MiddleName"=md5('$2')

        WHERE "N_LastName"=$1;

$$

LANGUAGE SQL;



CREATE FUNCTION "abc"."Reception_insert"(
IN R_FirstName varchar(255),
IN R_LastName varchar(255),  
IN R_Address varchar(255),
IN R_PhoneNumber int8, 
OUT RSeq INTEGER)

AS $$

BEGIN

 insert into "abc"."Reception"("R_FirstName","R_LastName","R_Address","R_PhoneNumber") values ($1,$2,$3,$4);

 select ("R_ID") into RSeq from "abc"."Reception" r where r."R_FirstName"=$1 and r."R_LastName"=$2;

END;
$$
Language plpgsql;


select "abc"."Reception_insert"('Nishant','Ramesh','454646454',199670824);


CREATE FUNCTION "abc"."Reception_update"(in "R_FirstName" varchar(255),in "R_LastName" varchar(255)) RETURNS void AS $$

    update "abc"."Reception" set "R_LastName"=md5('$2')

        WHERE "R_LastName"=$1;

$$

LANGUAGE SQL;


CREATE FUNCTION "abc"."Reception_delete"(in "R_FirstName" varchar(255),in "R_LastName" varchar(255)) RETURNS void AS $$

    delete "abc"."Reception" set "R_LastName"=md5('$2')

        WHERE "R_LastName"=$1;

$$

LANGUAGE SQL;

CREATE FUNCTION "abc"."Room_insert"(
IN Room_Number int4,
IN Room_Cost numeric(10,2),
IN Room_Available bool,  
OUT RoomSeq INTEGER)

AS $$

BEGIN

 insert into "abc"."Room"("Room_Number","Room_Cost","Room_Available") values ($1,$2,$3);

 select ("Room_ID") into RoomSeq from "abc"."Room" room where room."Room_Cost"=$2 and room."Room_Number"=$1;

END;
$$
Language plpgsql;


select "abc"."Room_insert"(343,4546,'y');


CREATE FUNCTION "abc"."Room_update"(in "Room_Number" int4,in "Room_cost" numeric(10,2)) RETURNS void AS $$

    update "abc"."Room" set "R_LastName"=md5('$2')

        WHERE "R_LastName"=$1;

$$

LANGUAGE SQL;


CREATE FUNCTION "abc"."Room_delete"(in "R_FirstName" varchar(255),in "R_LastName" varchar(255)) RETURNS void AS $$

    delete "abc"."Reception" set "R_LastName"=md5('$2')

        WHERE "R_LastName"=$1;

$$

LANGUAGE SQL;


CREATE FUNCTION "abc"."Medicines_insert"(
IN M_Name varchar(255),
IN M_Picture varchar(255), 
IN M_Price numeric(10,2), 
OUT MSeq INTEGER)

AS $$

BEGIN

 insert into "abc"."Medicines"("M_Name","M_Picture","M_Price") values ($1,$2,$3);

 select ("M_ID") into MSeq from "abc"."Medicines" m where m."M_Name"=$1 and m."M_Picture"=$2;

END;
$$
Language plpgsql;


select "abc"."Medicines_insert"('Nishant','Maurya',34);




CREATE FUNCTION "abc"."Suppliers_insert"(
IN S_Name varchar(255),
IN S_Address varchar(255),
IN DiscountPercentage float4,  
OUT SSeq INTEGER)

AS $$

BEGIN

 insert into "abc"."Suppliers"("S_Name","S_Address","DiscountPercentage") values ($1,$2,$3);

 select ("S_ID") into SSeq from "abc"."Suppliers" s where s."S_Name"=$1 and s."S_Address"=$2;

END;
$$
Language plpgsql;


select "abc"."Suppliers_insert"('Nishant','Maurya',45.00);







CREATE FUNCTION "abc"."Appointments_insert"(
IN Services varchar(255),
IN App_Date date,
IN App_On_Date varchar(255),
IN R_FirstName varchar(255),
IN R_LastName varchar(255),
IN P_FirstName varchar(255),
IN P_LastName varchar(255),
IN D_FirstName varchar(255),
IN D_LastName varchar(255),
OUT ASeq INTEGER)

AS $$

DECLARE rid int4;
pid int4;
did int4;

BEGIN

 select (ri."R_ID") into rid from "abc"."Reception" ri where ri."R_FirstName"=$4 and ri."R_LastName"=$5;

 select (pi."P_ID") into pid from "abc"."Patients" pi where pi."P_FirstName"=$6 and pi."P_LastName"=$7;

 select (di."D_ID") into did from "abc"."Doctors" di where di."D_FirstName"=$8 and di."D_LastName"=$9;

 insert into "abc"."Appointments"("Services","App_Date","App_On_Date","R_ID","P_ID","D_ID") values ($1,$2,$3,rid,pid,did);

 select ("App_ID") into ASeq from "abc"."Appointments" a where a."R_ID"=rid and a."P_ID"=pid and a."D_ID"=did and a."App_Date"=$2;

 

END;

$$

LANGUAGE plpgsql;

select "abc"."Appointments_insert"('Nishant','1993-08-24','dfd','dfdf','sds','sfsf','dfs','sfs','dff');







CREATE FUNCTION "abc"."Bills_insert"(
IN B_Amount varchar(255),
IN B_Date date,
IN B_DueDate varchar(255),
IN D_FirstName varchar(255),
IN D_LastName varchar(255),
IN P_FirstName varchar(255),
IN P_LastName varchar(255),
Test_Type char(255),
Test_Fee numeric(10,2),
Diag_Fees numeric(10,2),
Presc_Fee numeric(10,2),
Adm_Date date,
DischargeDate varchar(255),
OUT BSeq INTEGER)

AS $$

DECLARE 
did int4;
pid int4;
testid int4;
diagid int4;
prescid int4;
admid int4;

BEGIN

 select (di."D_ID") into did from "abc"."Doctors" di where di."D_FirstName"=$4 and di."D_LastName"=$5;

 select (pi."P_ID") into pid from "abc"."Patients" pi where pi."P_FirstName"=$6 and pi."P_LastName"=$7;

 select (ti."Test_ID") into testid from "abc"."Test" ti where ti."Test_Type"=$8 and ti."Test_Fee"=$9;

 select (dii."Diag_ID") into diagid from "abc"."Diag" dii where dii."Diag_Fees"=$10;

 select (pri."Presc_ID") into prescid from "abc"."Presc" pri where pri."Presc_Fee"=$11;

 select (ai."Adm_ID") into admid from "abc"."Admits" ai where ai."Adm_Date"=$12 and ai."DischargeDate"=$13;


 insert into "abc"."Bills"("B_Amount","B_Date","B_DueDate","D_ID","P_ID","Test_ID","Diag_ID","Presc_ID","Adm_ID") values ($1,$2,$3,did,pid,testid,diagid,prescid,admid);

 select ("B_ID") into BSeq from "abc"."Bills" b where b."D_ID"=did and b."P_ID"=pid and b."Test_ID"=testid and b."Diag_ID"=diagid and b."Presc_ID"=prescid and b."Adm_ID"=admid and b."B_Date"=$2;

END;

$$

LANGUAGE plpgsql;

select "abc"."Appointments_insert"(575,'1993-08-24','1993-08-24','dfdf','sds','sfsf','dfs','s',34,45,45,'1993-08-24','dff');









CREATE FUNCTION "abc"."Test_insert"(
IN Test_Type varchar(255),
IN Test_Fee numeric(10,2),
IN D_FirstName varchar(255),
IN D_LastName varchar(255),
IN P_FirstName varchar(255),
IN P_LastName varchar(255),
App_Date date,
OUT TSeq INTEGER)

AS $$

DECLARE 
did int4;
pid int4;
appid int4;

BEGIN

 select (di."D_ID") into did from "abc"."Doctors" di where di."D_FirstName"=$3 and di."D_LastName"=$4;

 select (pi."P_ID") into pid from "abc"."Patients" pi where pi."P_FirstName"=$5 and pi."P_LastName"=$6;

 select (ai."App_ID") into appid from "abc"."Appointments" ai where ai."App_Date"=$7;


 insert into "abc"."Test"("Test_Type","Test_Fee","D_ID","P_ID","App_ID") values ($1,$2,did,pid,appid);

 select ("Test_ID") into TSeq from "abc"."Test" t where t."D_ID"=did and t."P_ID"=pid and t."App_ID"=appid and b."Test_Fee"=$2;

END;

$$

LANGUAGE plpgsql;

select "abc"."Appointments_insert"('575',45,'1993-08-24','dfdf','sds','sfsf','1993-08-24');











CREATE FUNCTION "abc"."CCDetails_insert"(
IN Address varchar(255),
IN Phone_Number int4,
IN D_FirstName varchar(255),
IN D_LastName varchar(255),
OUT CCSeq INTEGER)

AS $$

DECLARE 
pid int4;


BEGIN

 select (pi."P_ID") into pid from "abc"."Patients" pi where pi."P_FirstName"=$3 and pi."P_LastName"=$4;


 insert into "abc"."CCDetails"("Address","Phone_Number","P_ID") values ($1,$2,pid);

 select ("CC_Number") from "abc"."CCDetails" c where c."P_ID"=pid and c."Address"=$1;

END;

$$

LANGUAGE plpgsql;

select "abc"."CCDetails_insert"('575',19930824,'1993-08-24','dfdf');