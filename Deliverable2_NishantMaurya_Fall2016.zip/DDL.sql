

-- ----------------------------
-- Table structure for Patient
-- ----------------------------
DROP SEQUENCE IF EXISTS "abc"."Patient_P_ID_seq";
CREATE SEQUENCE "abc"."Patient_P_ID_seq"
INCREMENT 1
MINVALUE 1
NO MAXVALUE
START 1
CACHE 1
NO CYCLE;

DROP TABLE IF EXISTS "abc"."Patient";
CREATE TABLE "abc"."Patient" (
"P_ID" int4 PRIMARY KEY DEFAULT nextval('"abc"."Patient_P_ID_seq"'),
"P_FirstName" varchar(255)   NOT NULL,
"P_LastName" varchar(255)    ,
"P_MiddleName" varchar(255)    ,
"P_Gender" varchar(255)    ,
"P_DOB" date
);
ALTER TABLE "abc"."Patient" DROP COLUMN "P_Gender";
ALTER TABLE "abc"."Patient" ALTER COLUMN "P_ID" TYPE int4;

-- ----------------------------
-- Table structure for Credit_Card_Details
-- ----------------------------
DROP TABLE IF EXISTS "abc"."Credit_Card_Details";
CREATE TABLE "abc"."Credit_Card_Details" (
"CC_Number" int8 PRIMARY KEY,
"Address" varchar(255)    ,
"Phone_Number" int4 NOT NULL,
"P_ID" int4 NOT NULL REFERENCES "abc"."Patient"("P_ID")
);
ALTER TABLE "abc"."Credit_Card_Details" ADD COLUMN "CVV" int2;
ALTER TABLE "abc"."Credit_Card_Details" ALTER COLUMN "Phone_Number" TYPE int8;

-- ----------------------------
-- Table structure for Login
-- ----------------------------
DROP TABLE IF EXISTS "abc"."Login";
CREATE TABLE "abc"."Login" (
"P_ID" int8 NOT NULL REFERENCES "abc"."Patient"("P_ID"),
"P_EmailAddress" varchar(255)   NOT NULL,
"P_Password" varchar(255)   NOT NULL,
"P_DateCreated" date
);
ALTER TABLE "abc"."Login" DROP COLUMN "P_DateCreated";
ALTER TABLE "abc"."Login" ALTER COLUMN "P_ID" TYPE int4;


-- ----------------------------
-- Table structure for Doctor
-- ----------------------------
DROP SEQUENCE IF EXISTS "abc"."Doctor_D_ID_seq";
CREATE SEQUENCE "abc"."Doctor_D_ID_seq"
INCREMENT 1
MINVALUE 1
NO MAXVALUE
START 1
CACHE 1
NO CYCLE;

DROP TABLE IF EXISTS "abc"."Doctor";
CREATE TABLE "abc"."Doctor" (
"D_ID" int4 PRIMARY KEY DEFAULT nextval('"abc"."Doctor_D_ID_seq"'),
"D_FirstName" varchar(255)   NOT NULL,
"D_MiddleName" varchar(255)    ,
"D_LastName" varchar(255)    ,
"D_Gender" varchar(255)    ,
"D_Fees" numeric(10,2) NOT NULL CHECK("D_Fees" > 0),
"Discipline" varchar(255)    ,
"D_PhoneNumber" int4 NOT NULL
);
ALTER TABLE "abc"."Doctor" DROP COLUMN "D_Gender";
ALTER TABLE "abc"."Doctor" ALTER COLUMN "D_PhoneNumber" TYPE int8;

-- ----------------------------
-- Table structure for Nurse
-- ----------------------------

DROP SEQUENCE IF EXISTS "abc"."Nurse_N_ID_seq";
CREATE SEQUENCE "abc"."Nurse_N_ID_seq"
INCREMENT 1
MINVALUE 1
NO MAXVALUE
START 1
CACHE 1
NO CYCLE;

DROP TABLE IF EXISTS "abc"."Nurse";
CREATE TABLE "abc"."Nurse" (
"N_ID" int4 PRIMARY KEY DEFAULT nextval('"abc"."Nurse_N_ID_seq"'),
"N_FirstName" varchar(255)   NOT NULL,
"N_MiddleName" varchar(255)    ,
"N_LastName" varchar(255)    ,
"N_Gender" varchar(255)    ,
"N_PhoneNumber" int4 NOT NULL,
"N_Address" varchar(255)    
);
ALTER TABLE "abc"."Nurse" DROP COLUMN "N_Gender";
ALTER TABLE "abc"."Nurse" ALTER COLUMN "N_PhoneNumber" TYPE int8;


-- ----------------------------
-- Table structure for Receptionist
-- ----------------------------

DROP SEQUENCE IF EXISTS "abc"."Receptionist_R_ID_seq";
CREATE SEQUENCE "abc"."Receptionist_R_ID_seq"
INCREMENT 1
MINVALUE 1
NO MAXVALUE
START 1
CACHE 1
NO CYCLE;

DROP TABLE IF EXISTS "abc"."Receptionist";
CREATE TABLE "abc"."Receptionist" (
"R_ID" int4 PRIMARY KEY DEFAULT nextval('"abc"."Receptionist_R_ID_seq"'),
"R_FirstName" varchar(255)   NOT NULL,
"R_MiddleName" varchar(255)    ,
"R_LastName" varchar(255)    ,
"R_Address" varchar(255)    ,
"R_PhoneNumber" int4 NOT NULL
);
ALTER TABLE "abc"."Receptionist" DROP COLUMN "R_MiddleName";
ALTER TABLE "abc"."Receptionist" ALTER COLUMN "R_PhoneNumber" TYPE int8;


-- ----------------------------
-- Table structure for Rooms
-- ----------------------------

DROP SEQUENCE IF EXISTS "abc"."Rooms_Room_ID_seq";
CREATE SEQUENCE "abc"."Rooms_Room_ID_seq"
INCREMENT 1
MINVALUE 1
NO MAXVALUE
START 1
CACHE 1
NO CYCLE;

DROP TABLE IF EXISTS "abc"."Rooms";
CREATE TABLE "abc"."Rooms" (
"Room_ID" int4 PRIMARY KEY DEFAULT nextval('"abc"."Rooms_Room_ID_seq"'),
"Room_Number" int4 NOT NULL,
"Room_Type" varchar(255)    ,
"Room_Cost" numeric(10,2) NOT NULL CHECK("Room_Cost" > 0),
"Room_Available" bool
);
ALTER TABLE "abc"."Rooms" DROP COLUMN "Room_Type";
ALTER TABLE "abc"."Rooms" ALTER COLUMN "Room_Number" TYPE int2;


-- ----------------------------
-- Table structure for Appointment
-- ----------------------------

DROP SEQUENCE IF EXISTS "abc"."Appointment_App_ID_seq";
CREATE SEQUENCE "abc"."Appointment_App_ID_seq"
INCREMENT 1
MINVALUE 1
NO MAXVALUE
START 1
CACHE 1
NO CYCLE;

DROP TABLE IF EXISTS "abc"."Appointment";
CREATE TABLE "abc"."Appointment" (
"App_ID" int4 PRIMARY KEY DEFAULT nextval('"abc"."Appointment_App_ID_seq"'),
"R_ID" int4 NOT NULL REFERENCES "abc"."Receptionist"("R_ID"),
"P_ID" int4 NOT NULL REFERENCES "abc"."Patient"("P_ID"),
"D_ID" int4 NOT NULL REFERENCES "abc"."Doctor"("D_ID"),
"Services" char(8)   ,
"App_Date" date,
"App_Time" time(6),
"App_On_Date" varchar(255)
);
ALTER TABLE "abc"."Appointment" DROP COLUMN "App_Time";
ALTER TABLE "abc"."Appointment" ALTER COLUMN "Services" TYPE varchar(255);


-- ----------------------------
-- Table structure for Admit
-- ----------------------------

DROP SEQUENCE IF EXISTS "abc"."Admit_Adm_ID_seq";
CREATE SEQUENCE "abc"."Admit_Adm_ID_seq"
INCREMENT 1
MINVALUE 1
NO MAXVALUE
START 1
CACHE 1
NO CYCLE;

DROP TABLE IF EXISTS "abc"."Admit";
CREATE TABLE "abc"."Admit" (
"Adm_ID" int4 PRIMARY KEY DEFAULT nextval('"abc"."Admit_Adm_ID_seq"'),
"P_ID" int4 NOT NULL REFERENCES "abc"."Patient"("P_ID"),
"N_ID" int4 NOT NULL REFERENCES "abc"."Nurse"("N_ID"),
"Room_ID" int4 NOT NULL REFERENCES "abc"."Rooms"("Room_ID"),
"Adm_Date" date NOT NULL,
"Adm_Time" time(6) NOT NULL,
"DischargeDate" date,
"Cost_Of_Room" int4 NOT NULL CHECK("Cost_Of_Room" > 0)
);
ALTER TABLE "abc"."Admit" DROP COLUMN "Adm_Time";
ALTER TABLE "abc"."Admit" ALTER COLUMN "DischargeDate" TYPE varchar(255);



-- ----------------------------
-- Table structure for Insurance_policy
-- ----------------------------

DROP SEQUENCE IF EXISTS "abc"."Insurance_Policy_IP_PolicyNumber_seq";
CREATE SEQUENCE "abc"."Insurance_Policy_IP_PolicyNumber_seq"
INCREMENT 1
MINVALUE 1
NO MAXVALUE
START 1
CACHE 1
NO CYCLE;

DROP TABLE IF EXISTS "abc"."Insurance_policy";
CREATE TABLE "abc"."Insurance_policy" (
"P_ID" int4 NOT NULL REFERENCES "abc"."Patient"("P_ID"),
"IP_PolicyNumber" int4 PRIMARY KEY DEFAULT nextval('"abc"."Insurance_Policy_IP_PolicyNumber_seq"'),
"IP_Coverage" int4 NOT NULL CHECK("IP_Coverage" > 0),
"IP_Company" varchar(255)   NOT NULL,
"IP_CoveragePrecentage" float4 NOT NULL
);
ALTER TABLE "abc"."Insurance_policy" ALTER COLUMN "IP_Coverage" TYPE int4;



-- ----------------------------
-- Table structure for Accountant
-- ----------------------------

DROP SEQUENCE IF EXISTS "abc"."Accountant_A_ID_seq";
CREATE SEQUENCE "abc"."Accountant_A_ID_seq"
INCREMENT 1
MINVALUE 1
NO MAXVALUE
START 1
CACHE 1
NO CYCLE;

DROP TABLE IF EXISTS "abc"."Accountant";
CREATE TABLE "abc"."Accountant" (
"A_ID" int4 PRIMARY KEY DEFAULT nextval('"abc"."Accountant_A_ID_seq"'),
"IP_PolicyNumber" int4 NOT NULL REFERENCES "abc"."Insurance_policy"("IP_PolicyNumber"),
"A_Name" varchar(255)   NOT NULL,
"A_Address" varchar(255)    ,
"A_PhoneNumber" int4 NOT NULL,
"A_Gender" varchar(255)    
);

ALTER TABLE "abc"."Accountant" DROP COLUMN "A_Gender";
ALTER TABLE "abc"."Accountant" ALTER COLUMN "A_PhoneNumber" TYPE int8;


-- ----------------------------
-- Table structure for Diagnosis
-- ----------------------------

DROP SEQUENCE IF EXISTS "abc"."Diagnosis_Diag_ID_seq";
CREATE SEQUENCE "abc"."Diagnosis_Diag_ID_seq"
INCREMENT 1
MINVALUE 1
NO MAXVALUE
START 1
CACHE 1
NO CYCLE;

DROP TABLE IF EXISTS "abc"."Diagnosis";
CREATE TABLE "abc"."Diagnosis" (
"Diag_ID" int4 PRIMARY KEY DEFAULT nextval('"abc"."Diagnosis_Diag_ID_seq"'),
"App_ID" int4 NOT NULL REFERENCES "abc"."Appointment"("App_ID"),
"D_ID" int4 NOT NULL REFERENCES "abc"."Doctor"("D_ID"),
"P_ID" int4 NOT NULL REFERENCES "abc"."Patient"("P_ID"),
"Diag_Description" varchar(255)    ,
"Diag_Fees" numeric(10,2) NOT NULL CHECK("Diag_Fees" > 0)
);
ALTER TABLE "abc"."Diagnosis" DROP COLUMN "Diag_Description";
ALTER TABLE "abc"."Diagnosis" RENAME COLUMN "Diag_Fees" TO "Diag_Cost";



-- ----------------------------
-- Table structure for Medicine
-- ----------------------------

DROP SEQUENCE IF EXISTS "abc"."Medicine_M_ID_seq";
CREATE SEQUENCE "abc"."Medicine_M_ID_seq"
INCREMENT 1
MINVALUE 1
NO MAXVALUE
START 1
CACHE 1
NO CYCLE;

DROP TABLE IF EXISTS "abc"."Medicine";
CREATE TABLE "abc"."Medicine" (
"M_ID" int8 PRIMARY KEY DEFAULT nextval('"abc"."Medicine_M_ID_seq"'),
"M_Name" varchar(255)   NOT NULL,
"M_Picture" varchar(255)    ,
"M_Price" numeric(10,2) CHECK("M_Price" > 0),
"M_Quantity" int4 CHECK("M_Quantity" > 0)
);
ALTER TABLE "abc"."Medicine" DROP COLUMN "M_Quantity";
ALTER TABLE "abc"."Medicine" ALTER COLUMN "M_ID" TYPE int4;





-- ----------------------------
-- Table structure for M_Type
-- ----------------------------
DROP TABLE IF EXISTS "abc"."M_Type";
CREATE TABLE "abc"."M_Type" (
"Antibiotic" char(5)    ,
"Hormone" char(5)    ,
"Vitamins" char(5)    ,
"M_ID" int4 NOT NULL REFERENCES "abc"."Medicine"("M_ID")
);
ALTER TABLE "abc"."M_Type" DROP COLUMN "Hormone";
ALTER TABLE "abc"."M_Type" ALTER COLUMN "Vitamins" TYPE varchar(255);


-- ----------------------------
-- Table structure for M_Type1
-- ----------------------------

CREATE TABLE "abc"."M_Type1" (
"Amoxicillin" char(5)    ,
"Cefixime" varchar(255)    ,
"M_ID" int4 NOT NULL REFERENCES "abc"."Medicine"("M_ID")
);
ALTER TABLE "abc"."M_Type1" DROP COLUMN "Cefixime";
ALTER TABLE "abc"."M_Type1" ALTER COLUMN "Amoxicillin" TYPE varchar(255);


-- ----------------------------
-- Table structure for M_Type2
-- ----------------------------
DROP TABLE IF EXISTS "abc"."M_Type2";
CREATE TABLE "abc"."M_Type2" (
"Insulin" char(5)    ,
"M_ID" int4 NOT NULL REFERENCES "abc"."Medicine"("M_ID")
);
ALTER TABLE "abc"."M_Type2" ALTER COLUMN "Insulin" TYPE varchar(255);


-- ----------------------------
-- Table structure for M_Type3
-- ----------------------------
DROP TABLE IF EXISTS "abc"."M_Type3";
CREATE TABLE "abc"."M_Type3" (
"Prenatal" char(5)    ,
"Vitamin C" varchar(255)    ,
"M_ID" int4 NOT NULL REFERENCES "abc"."Medicine"("M_ID")
);
ALTER TABLE "abc"."M_Type3" ALTER COLUMN "Vitamin C" TYPE varchar(255);




-- ----------------------------
-- Table structure for Prescription
-- ----------------------------

DROP SEQUENCE IF EXISTS "abc"."Prescription_Presc_ID_seq";
CREATE SEQUENCE "abc"."Prescription_Presc_ID_seq"
INCREMENT 1
MINVALUE 1
NO MAXVALUE
START 1
CACHE 1
NO CYCLE;

DROP TABLE IF EXISTS "abc"."Prescription";
CREATE TABLE "abc"."Prescription" (
"Presc_ID" int4 PRIMARY KEY DEFAULT nextval('"abc"."Prescription_Presc_ID_seq"'),
"P_ID" int4 NOT NULL REFERENCES "abc"."Patient"("P_ID"),
"D_ID" int4 NOT NULL REFERENCES "abc"."Doctor"("D_ID"),
"App_ID" int4 NOT NULL REFERENCES "abc"."Appointment"("App_ID"),
"Presc_Date" date NOT NULL,
"Presc_Fee" numeric(10,2) NOT NULL CHECK("Presc_Fee" > 0),
"M_ID" int4 NOT NULL REFERENCES "abc"."Medicine"("M_ID")
);
ALTER TABLE "abc"."Prescription" DROP COLUMN "Presc_Date";
ALTER TABLE "abc"."Prescription" ALTER COLUMN "Presc_ID" TYPE int4;



-- ----------------------------
-- Table structure for Records
-- ----------------------------
DROP TABLE IF EXISTS "abc"."Records";
CREATE TABLE "abc"."Records" (
"P_ID" int4 NOT NULL REFERENCES "abc"."Patient"("P_ID"),
"App_ID" int4 NOT NULL REFERENCES "abc"."Appointment"("App_ID"),
"N_ID" int4 NOT NULL REFERENCES "abc"."Nurse"("N_ID"),
"P_CheckInTime" time(6),
"P_Height" float8,
"P_Weight" float8,
"P_BloodPressure" varchar(255)    ,
"P_BodyTemprature" int2
);
ALTER TABLE "abc"."Records" DROP COLUMN "P_Height";
ALTER TABLE "abc"."Records" ALTER COLUMN "P_BodyTemprature" TYPE numeric(10,2);



-- ----------------------------
-- Table structure for Supplier
-- ----------------------------
DROP SEQUENCE IF EXISTS "abc"."Supplier_S_ID_seq";
CREATE SEQUENCE "abc"."Supplier_S_ID_seq"
INCREMENT 1
MINVALUE 1
NO MAXVALUE
START 1
CACHE 1
NO CYCLE;

DROP TABLE IF EXISTS "abc"."Supplier";
CREATE TABLE "abc"."Supplier" (
"S_ID" int4 PRIMARY KEY DEFAULT nextval('"abc"."Supplier_S_ID_seq"'),
"S_Name" varchar(255)   NOT NULL,
"S_Address" varchar(255)    ,
"S_RName" varchar(255)   NOT NULL,
"DiscountPercentage" float4 NOT NULL CHECK("DiscountPercentage" > 0 AND "DiscountPercentage" < 100)
);
ALTER TABLE "abc"."Supplier" DROP COLUMN "S_RName";
ALTER TABLE "abc"."Supplier" ALTER COLUMN "DiscountPercentage" TYPE int2;


-- ----------------------------
-- Table structure for Supplier_Supplies_Medicine
-- ----------------------------
DROP TABLE IF EXISTS "abc"."Supplier_Supplies_Medicine";
CREATE TABLE "abc"."Supplier_Supplies_Medicine" (
"S_ID" int4 NOT NULL REFERENCES "abc"."Supplier"("S_ID"),
"M_ID" int2 REFERENCES "abc"."Medicine"("M_ID"),
"M_Name" varchar(255)    ,
"M_Cost" numeric(10,2) CHECK("M_Cost" > 0)
);
ALTER TABLE "abc"."Supplier_Supplies_Medicine" ALTER COLUMN "M_ID" TYPE int4;


-- ----------------------------
-- Table structure for Tests
-- ----------------------------
DROP SEQUENCE IF EXISTS "abc"."Tests_Test_ID_seq";
CREATE SEQUENCE "abc"."Tests_Test_ID_seq"
INCREMENT 1
MINVALUE 1
NO MAXVALUE
START 1
CACHE 1
NO CYCLE;

DROP TABLE IF EXISTS "abc"."Tests";
CREATE TABLE "abc"."Tests" (
"Test_ID" int4 PRIMARY KEY DEFAULT nextval('"abc"."Tests_Test_ID_seq"'),
"Test_Type" char(255)    ,
"Test_Fee" numeric(10,2) NOT NULL CHECK("Test_Fee" > 0),
"D_ID" int4 NOT NULL REFERENCES "abc"."Doctor"("D_ID"),
"P_ID" int4 NOT NULL REFERENCES "abc"."Patient"("P_ID"),
"App_ID" int4 NOT NULL REFERENCES "abc"."Appointment"("App_ID")
);
ALTER TABLE "abc"."Tests" DROP COLUMN "P_ID";
ALTER TABLE "abc"."Tests" ALTER COLUMN "Test_Type" TYPE varchar(255);


-- ----------------------------
-- Table structure for Billing
-- ----------------------------
DROP SEQUENCE IF EXISTS "abc"."Bill_B_ID_seq";
CREATE SEQUENCE "abc"."Bill_B_ID_seq"
INCREMENT 1
MINVALUE 1
NO MAXVALUE
START 1
CACHE 1
NO CYCLE;

DROP TABLE IF EXISTS "abc"."Billing";
CREATE TABLE "abc"."Billing" (
"B_ID" int4 PRIMARY KEY DEFAULT nextval('"abc"."Bill_B_ID_seq"'),
"B_Amount" float8 NOT NULL CHECK("B_Amount" > 0),
"B_Date" date NOT NULL,
"B_DueDate" varchar(255),
"D_ID" int4 REFERENCES "abc"."Doctor"("D_ID"),
"P_ID" int4 REFERENCES "abc"."Patient"("P_ID"),
"Test_ID" int4 REFERENCES "abc"."Tests"("Test_ID"),
"Diag_ID" int4 REFERENCES "abc"."Diagnosis"("Diag_ID"),
"Presc_ID" int4 REFERENCES "abc"."Prescription"("Presc_ID"),
"Adm_ID" int4 REFERENCES "abc"."Admit"("Adm_ID")
);
ALTER TABLE "abc"."Billing" ALTER COLUMN "B_DueDate" TYPE varchar(255);





ALTER TABLE "abc"."M_Type2" RENAME TO "Medicine_Type2";
ALTER TABLE "abc"."M_Type3" RENAME TO "Medicine_Type3";
ALTER TABLE "abc"."Login" RENAME TO "LoginDetails";
ALTER TABLE "abc"."Accountant" RENAME TO "Accountants";
ALTER TABLE "abc"."Admit" RENAME TO "Admits";
ALTER TABLE "abc"."Appointment" RENAME TO "Appointments";
ALTER TABLE "abc"."Billing" RENAME TO "Bills";
ALTER TABLE "abc"."Credit_Card_Details" RENAME TO "CCDetails";
ALTER TABLE "abc"."Diagnosis" RENAME TO "Diag";
ALTER TABLE "abc"."Doctor" RENAME TO "Doctors";
ALTER TABLE "abc"."Insurance_policy" RENAME TO "I_P";
ALTER TABLE "abc"."Medicine" RENAME TO "Medicines";
ALTER TABLE "abc"."Nurse" RENAME TO "Nurses";
ALTER TABLE "abc"."Patient" RENAME TO "Patients";
ALTER TABLE "abc"."Prescription" RENAME TO "Presc";
ALTER TABLE "abc"."Receptionist" RENAME TO "Reception";
ALTER TABLE "abc"."Rooms" RENAME TO "Room";
ALTER TABLE "abc"."Supplier" RENAME TO "Suppliers";
ALTER TABLE "abc"."Tests" RENAME TO "Test";
ALTER TABLE "abc"."M_Type" RENAME TO "Medicine_Type";
ALTER TABLE "abc"."M_Type1" RENAME TO "Medicine_Type1";
ALTER TABLE "abc"."Records" RENAME TO "Patient_Records";
ALTER TABLE "abc"."Supplier_Supplies_Medicine" RENAME TO "SSMedicine";